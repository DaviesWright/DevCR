import { prisma } from "@/lib/prisma";

// Self-service report builder's safety boundary: a manager can only build a chart from one of
// these allowlisted entities, grouped by one of its allowlisted dimensions, measuring one of its
// allowlisted numeric fields. Nothing here accepts a raw field name or raw SQL from the client —
// each entity's fetchRows() is a hand-written, typed Prisma query that already flattens relation
// fields (e.g. customer.segment) into plain string/number values, so grouping/filtering/
// aggregating afterward is just array math in JS, never a dynamically-built query. Dataset sizes
// here are small (dozens to low hundreds of rows), so this is fine without DB-level GROUP BY.

export type ReportEntityKey = "LEAD" | "CUSTOMER" | "OPPORTUNITY" | "SALE" | "COMMISSION" | "COMPLAINT" | "UNIT";
export type ReportFieldOption = { key: string; label: string };
export type ReportRow = Record<string, string | number>;

type ReportEntityDef = {
  label: string;
  dimensions: ReportFieldOption[];
  measures: ReportFieldOption[];
  fetchRows: () => Promise<ReportRow[]>;
};

const REPORT_ENTITIES: Record<ReportEntityKey, ReportEntityDef> = {
  LEAD: {
    label: "Leads",
    dimensions: [
      { key: "status", label: "Status" },
      { key: "qualificationStatus", label: "Qualification" },
      { key: "source", label: "Source" },
      { key: "segment", label: "Buyer Segment" },
      { key: "assignedTo", label: "Assigned To" },
    ],
    measures: [
      { key: "bantScore", label: "BANT Score" },
      { key: "score", label: "Engagement Score" },
    ],
    fetchRows: async () => {
      const rows = await prisma.lead.findMany({
        where: { deletedAt: null },
        select: {
          status: true,
          qualificationStatus: true,
          bantScore: true,
          score: true,
          source: { select: { name: true } },
          customer: { select: { segment: true } },
          assignedTo: { select: { firstName: true, lastName: true } },
        },
      });
      return rows.map((l) => ({
        status: l.status,
        qualificationStatus: l.qualificationStatus,
        source: l.source.name,
        segment: l.customer.segment ?? "Unknown",
        assignedTo: l.assignedTo ? `${l.assignedTo.firstName} ${l.assignedTo.lastName}` : "Unassigned",
        bantScore: l.bantScore,
        score: l.score,
      }));
    },
  },
  CUSTOMER: {
    label: "Customers",
    dimensions: [
      { key: "segment", label: "Segment" },
      { key: "kycStatus", label: "KYC Status" },
      { key: "sentiment", label: "Sentiment" },
    ],
    measures: [{ key: "engagementScore", label: "Engagement Score" }],
    fetchRows: async () => {
      const rows = await prisma.customer.findMany({
        where: { deletedAt: null },
        select: { segment: true, kycStatus: true, sentiment: true, engagementScore: true },
      });
      return rows.map((c) => ({
        segment: c.segment ?? "Unknown",
        kycStatus: c.kycStatus,
        sentiment: c.sentiment,
        engagementScore: Number(c.engagementScore),
      }));
    },
  },
  OPPORTUNITY: {
    label: "Opportunities",
    dimensions: [
      { key: "stage", label: "Stage" },
      { key: "owner", label: "Owner" },
    ],
    measures: [
      { key: "expectedValue", label: "Expected Value" },
      { key: "probability", label: "Probability" },
    ],
    fetchRows: async () => {
      const rows = await prisma.opportunity.findMany({
        where: { deletedAt: null },
        select: {
          stage: true,
          expectedValue: true,
          probability: true,
          owner: { select: { firstName: true, lastName: true } },
        },
      });
      return rows.map((o) => ({
        stage: o.stage,
        owner: `${o.owner.firstName} ${o.owner.lastName}`,
        expectedValue: Number(o.expectedValue),
        probability: o.probability,
      }));
    },
  },
  SALE: {
    label: "Sales",
    dimensions: [
      { key: "status", label: "Status" },
      { key: "development", label: "Development" },
    ],
    measures: [{ key: "salePrice", label: "Sale Price" }],
    fetchRows: async () => {
      const rows = await prisma.sale.findMany({
        where: { deletedAt: null },
        select: { status: true, salePrice: true, unit: { select: { development: { select: { name: true } } } } },
      });
      return rows.map((s) => ({
        status: s.status,
        development: s.unit.development.name,
        salePrice: Number(s.salePrice),
      }));
    },
  },
  COMMISSION: {
    label: "Commissions",
    dimensions: [
      { key: "status", label: "Status" },
      { key: "tranche", label: "Tranche" },
      { key: "agent", label: "Agent" },
    ],
    measures: [{ key: "amount", label: "Amount" }],
    fetchRows: async () => {
      const rows = await prisma.commission.findMany({
        select: { status: true, tranche: true, amount: true, agent: { select: { user: { select: { firstName: true, lastName: true } } } } },
      });
      return rows.map((c) => ({
        status: c.status,
        tranche: c.tranche,
        agent: `${c.agent.user.firstName} ${c.agent.user.lastName}`,
        amount: Number(c.amount),
      }));
    },
  },
  COMPLAINT: {
    label: "Complaints",
    dimensions: [
      { key: "status", label: "Status" },
      { key: "priority", label: "Priority" },
      { key: "category", label: "Category" },
    ],
    measures: [],
    fetchRows: async () => {
      const rows = await prisma.complaint.findMany({
        select: { status: true, priority: true, category: { select: { name: true } } },
      });
      return rows.map((c) => ({ status: c.status, priority: c.priority, category: c.category.name }));
    },
  },
  UNIT: {
    label: "Units",
    dimensions: [
      { key: "status", label: "Status" },
      { key: "development", label: "Development" },
      { key: "propertyType", label: "Property Type" },
    ],
    measures: [{ key: "currentPrice", label: "Current Price" }],
    fetchRows: async () => {
      const rows = await prisma.unit.findMany({
        where: { deletedAt: null },
        select: { status: true, currentPrice: true, development: { select: { name: true } }, propertyType: { select: { name: true } } },
      });
      return rows.map((u) => ({
        status: u.status,
        development: u.development.name,
        propertyType: u.propertyType.name,
        currentPrice: Number(u.currentPrice),
      }));
    },
  },
};

export const REPORT_ENTITY_KEYS = Object.keys(REPORT_ENTITIES) as ReportEntityKey[];

export function getReportEntityDef(entity: ReportEntityKey): ReportEntityDef {
  const def = REPORT_ENTITIES[entity];
  if (!def) throw new Error(`Unknown report entity "${entity}"`);
  return def;
}

export function isValidDimension(entity: ReportEntityKey, field: string): boolean {
  return getReportEntityDef(entity).dimensions.some((d) => d.key === field);
}

export function isValidMeasure(entity: ReportEntityKey, field: string): boolean {
  return getReportEntityDef(entity).measures.some((m) => m.key === field);
}

export function getReportableEntities() {
  return REPORT_ENTITY_KEYS.map((key) => ({
    key,
    label: REPORT_ENTITIES[key].label,
    dimensions: REPORT_ENTITIES[key].dimensions,
    measures: REPORT_ENTITIES[key].measures,
  }));
}
