"use client";

import * as React from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { FileText, Loader2, CheckCircle2, ExternalLink } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { cn, formatCurrency, relativeTime } from "@/lib/utils";
import { moveOpportunityStage, generateReservationForm } from "@/lib/actions/sales";
import { PIPELINE_STAGES, STAGE_LABEL, type PipelineCard } from "@/lib/queries/sales";

const STAGE_ACCENT: Record<string, string> = {
  PROSPECTING: "border-t-muted-foreground/40",
  QUALIFIED: "border-t-info",
  SITE_VISIT: "border-t-info",
  RESERVATION: "border-t-warning",
  NEGOTIATION: "border-t-warning",
  CONTRACT: "border-t-highlight",
  CLOSED_WON: "border-t-success",
  CLOSED_LOST: "border-t-destructive",
};

export function PipelineBoard({ opportunities, currentUserId }: { opportunities: PipelineCard[]; currentUserId: string }) {
  const router = useRouter();
  const [cards, setCards] = React.useState(opportunities);
  const [draggingId, setDraggingId] = React.useState<string | null>(null);
  const [dragOverStage, setDragOverStage] = React.useState<string | null>(null);
  const [generatingId, setGeneratingId] = React.useState<string | null>(null);

  React.useEffect(() => setCards(opportunities), [opportunities]);

  async function handleGenerateReservation(opportunityId: string) {
    setGeneratingId(opportunityId);
    try {
      await generateReservationForm(opportunityId, currentUserId);
      router.refresh();
    } finally {
      setGeneratingId(null);
    }
  }

  const byStage = React.useMemo(() => {
    const map = new Map<string, PipelineCard[]>();
    for (const stage of PIPELINE_STAGES) map.set(stage, []);
    for (const card of cards) map.get(card.stage)?.push(card);
    return map;
  }, [cards]);

  async function handleDrop(stage: string) {
    setDragOverStage(null);
    const id = draggingId;
    setDraggingId(null);
    if (!id) return;

    const current = cards.find((c) => c.id === id);
    if (!current || current.stage === stage) return;

    // Optimistic move, then persist; refresh reconciles with the server.
    setCards((prev) => prev.map((c) => (c.id === id ? { ...c, stage: stage as never } : c)));
    await moveOpportunityStage(id, stage, currentUserId);
    router.refresh();
  }

  return (
    <div className="flex gap-4 overflow-x-auto pb-4">
      {PIPELINE_STAGES.map((stage) => {
        const stageCards = byStage.get(stage) ?? [];
        const stageValue = stageCards.reduce((sum, c) => sum + c.expectedValue, 0);

        return (
          <div
            key={stage}
            onDragOver={(e) => {
              e.preventDefault();
              setDragOverStage(stage);
            }}
            onDragLeave={() => setDragOverStage((s) => (s === stage ? null : s))}
            onDrop={(e) => {
              e.preventDefault();
              handleDrop(stage);
            }}
            className={cn(
              "flex w-72 shrink-0 flex-col gap-2 rounded-lg border border-border bg-muted/40 p-2 transition-colors",
              dragOverStage === stage && "border-primary bg-accent"
            )}
          >
            <div className="flex items-center justify-between px-1.5 py-1">
              <span className="text-sm font-semibold text-foreground">{STAGE_LABEL[stage]}</span>
              <span className="text-xs text-muted-foreground">{stageCards.length}</span>
            </div>
            <p className="px-1.5 text-xs text-muted-foreground">{formatCurrency(stageValue)}</p>

            <div className="flex min-h-16 flex-col gap-2">
              {stageCards.map((card) => (
                <Card
                  key={card.id}
                  draggable
                  onDragStart={() => setDraggingId(card.id)}
                  onDragEnd={() => setDraggingId(null)}
                  className={cn(
                    "cursor-grab border-t-2 shadow-sm active:cursor-grabbing",
                    STAGE_ACCENT[stage],
                    draggingId === card.id && "opacity-40"
                  )}
                >
                  <CardContent className="p-3">
                    <div className="flex items-start justify-between gap-1">
                      <p className="text-sm font-medium text-foreground">{card.customerName}</p>
                      <Link
                        href={`/sales/opportunities/${card.id}`}
                        className="shrink-0 text-muted-foreground hover:text-foreground"
                        title="View opportunity"
                        onClick={(e) => e.stopPropagation()}
                      >
                        <ExternalLink className="size-3.5" />
                      </Link>
                    </div>
                    <p className="text-xs text-muted-foreground">{card.unitNumber ?? "No unit yet"}</p>
                    <div className="mt-2 flex items-center justify-between">
                      <span className="text-sm font-semibold tabular-nums">
                        {formatCurrency(card.expectedValue, card.currency)}
                      </span>
                      <span className="text-xs text-muted-foreground">{card.probability}%</span>
                    </div>
                    <div className="mt-2 flex items-center justify-between text-xs text-muted-foreground">
                      <span>{card.ownerName}</span>
                      <span>{relativeTime(card.updatedAt)}</span>
                    </div>
                    {card.unitId && stage !== "CLOSED_WON" && stage !== "CLOSED_LOST" && (
                      <div className="mt-2 border-t border-border pt-2">
                        {card.reservation ? (
                          <span
                            className={cn(
                              "flex items-center gap-1 text-xs",
                              card.reservation.expired ? "text-destructive" : "text-success"
                            )}
                          >
                            <CheckCircle2 className="size-3" />
                            {card.reservation.expired ? "Hold expired" : `Held · ${relativeTime(card.reservation.expiryDate)}`}
                          </span>
                        ) : (
                          <Button
                            variant="ghost"
                            size="sm"
                            className="h-7 px-1.5 text-xs"
                            disabled={generatingId === card.id}
                            onClick={(e) => {
                              e.stopPropagation();
                              handleGenerateReservation(card.id);
                            }}
                          >
                            {generatingId === card.id ? (
                              <Loader2 className="size-3 animate-spin" />
                            ) : (
                              <FileText className="size-3" />
                            )}{" "}
                            Generate Reservation Form
                          </Button>
                        )}
                      </div>
                    )}
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        );
      })}
    </div>
  );
}
