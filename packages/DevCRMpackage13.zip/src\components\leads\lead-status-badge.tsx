import { Badge } from "@/components/ui/badge";

const STATUS_VARIANT = {
  NEW: "info",
  CONTACTED: "secondary",
  NURTURING: "warning",
  NO_RESPONSE: "outline",
  QUALIFIED: "success",
  REAL_OPPORTUNITY: "highlight",
  UNQUALIFIED: "destructive",
  CONVERTED: "highlight",
} as const;

const STATUS_LABEL: Record<string, string> = {
  NEW: "New",
  CONTACTED: "Contacted",
  NURTURING: "Nurturing",
  NO_RESPONSE: "No response",
  QUALIFIED: "Qualified",
  REAL_OPPORTUNITY: "Real Opportunity",
  UNQUALIFIED: "Unqualified",
  CONVERTED: "Converted",
};

export function LeadStatusBadge({ status }: { status: keyof typeof STATUS_VARIANT }) {
  return (
    <Badge variant={STATUS_VARIANT[status]} dot>
      {STATUS_LABEL[status]}
    </Badge>
  );
}

const QUALIFICATION_VARIANT = {
  QUALIFIED: "success",
  REVIEW: "warning",
  UNQUALIFIED: "outline",
} as const;

const QUALIFICATION_LABEL: Record<string, string> = {
  QUALIFIED: "Qualified",
  REVIEW: "Needs review",
  UNQUALIFIED: "Unqualified",
};

export function QualificationBadge({ status }: { status: keyof typeof QUALIFICATION_VARIANT }) {
  return <Badge variant={QUALIFICATION_VARIANT[status]}>{QUALIFICATION_LABEL[status]}</Badge>;
}

const SEGMENT_LABEL: Record<string, string> = {
  LOCAL_RESIDENTIAL: "Local Residential",
  DIASPORA: "Diaspora",
  CORPORATE: "Corporate",
  INVESTOR: "Investor",
};

export function SegmentBadge({ segment }: { segment: string }) {
  return <Badge variant="outline">{SEGMENT_LABEL[segment] ?? segment}</Badge>;
}
