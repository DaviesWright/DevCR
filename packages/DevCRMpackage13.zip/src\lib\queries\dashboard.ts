import { prisma } from "@/lib/prisma";

export type DashboardKpis = {
  activeLeads: number;
  activeLeadsChangePct: number | null;
  unitsAvailable: number;
  totalUnits: number;
  revenue: number;
  openComplaints: number;
};

export async function getDashboardKpis(): Promise<DashboardKpis> {
  const now = new Date();
  const thirtyDaysAgo = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);
  const sixtyDaysAgo = new Date(now.getTime() - 60 * 24 * 60 * 60 * 1000);

  const [
    activeLeads,
    leadsLast30,
    leadsPrior30,
    unitsAvailable,
    totalUnits,
    salesAgg,
    openComplaints,
  ] = await Promise.all([
    prisma.lead.count({ where: { status: { in: ["NEW", "CONTACTED", "QUALIFIED"] }, deletedAt: null } }),
    prisma.lead.count({ where: { createdAt: { gte: thirtyDaysAgo }, deletedAt: null } }),
    prisma.lead.count({ where: { createdAt: { gte: sixtyDaysAgo, lt: thirtyDaysAgo }, deletedAt: null } }),
    prisma.unit.count({ where: { status: "AVAILABLE", deletedAt: null } }),
    prisma.unit.count({ where: { deletedAt: null } }),
    prisma.sale.aggregate({
      where: { status: { in: ["ACTIVE", "COMPLETED"] }, deletedAt: null },
      _sum: { salePrice: true },
    }),
    prisma.complaint.count({ where: { status: { notIn: ["RESOLVED", "CLOSED"] } } }),
  ]);

  const activeLeadsChangePct =
    leadsPrior30 > 0 ? Math.round(((leadsLast30 - leadsPrior30) / leadsPrior30) * 100) : null;

  return {
    activeLeads,
    activeLeadsChangePct,
    unitsAvailable,
    totalUnits,
    revenue: Number(salesAgg._sum.salePrice ?? 0),
    openComplaints,
  };
}

export type PipelineStage = {
  stage: string;
  count: number;
  value: number;
};

const STAGE_ORDER = [
  "PROSPECTING",
  "QUALIFIED",
  "SITE_VISIT",
  "RESERVATION",
  "NEGOTIATION",
  "CONTRACT",
  "CLOSED_WON",
] as const;

const STAGE_LABEL: Record<string, string> = {
  PROSPECTING: "Prospecting",
  QUALIFIED: "Qualified",
  SITE_VISIT: "Site Visit",
  RESERVATION: "Reservation",
  NEGOTIATION: "Negotiation",
  CONTRACT: "Contract",
  CLOSED_WON: "Closed Won",
};

export async function getPipelineFunnel(): Promise<PipelineStage[]> {
  const grouped = await prisma.opportunity.groupBy({
    by: ["stage"],
    where: { stage: { not: "CLOSED_LOST" }, deletedAt: null },
    _count: { _all: true },
    _sum: { expectedValue: true },
  });

  const byStage = new Map(grouped.map((g) => [g.stage, g]));

  return STAGE_ORDER.map((stage) => ({
    stage: STAGE_LABEL[stage],
    count: byStage.get(stage)?._count._all ?? 0,
    value: Number(byStage.get(stage)?._sum.expectedValue ?? 0),
  }));
}

export type RecentActivityItem = {
  id: string;
  actor: string;
  description: string;
  occurredAt: Date;
};

export async function getRecentActivity(limit = 6): Promise<RecentActivityItem[]> {
  const activities = await prisma.leadActivity.findMany({
    orderBy: { occurredAt: "desc" },
    take: limit,
    include: {
      createdBy: { select: { firstName: true, lastName: true } },
      lead: { select: { customer: { select: { firstName: true, lastName: true } } } },
    },
  });

  return activities.map((a) => ({
    id: a.id,
    actor: `${a.createdBy.firstName} ${a.createdBy.lastName}`,
    description: `${a.type.replace("_", " ").toLowerCase()} — ${a.lead.customer.firstName} ${a.lead.customer.lastName}${a.description ? `: ${a.description}` : ""}`,
    occurredAt: a.occurredAt,
  }));
}
