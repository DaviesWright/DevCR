import { prisma } from "@/lib/prisma";

// Pre-conversion pipeline — distinct from the post-conversion Opportunity Kanban at /sales.
// Tracks a contacted Lead through Nurturing toward Real Opportunity / Convert, surfacing
// staleness per stage since that's the single biggest finding in the real pipeline diagnostic
// (203 leads sat in Nurturing, 65% untouched 60+ days).
export const NURTURE_STAGES = ["NEW", "CONTACTED", "NURTURING", "QUALIFIED", "REAL_OPPORTUNITY"] as const;

export const NURTURE_STAGE_LABEL: Record<string, string> = {
  NEW: "New",
  CONTACTED: "Contacted",
  NURTURING: "Nurturing",
  QUALIFIED: "Qualified",
  REAL_OPPORTUNITY: "Real Opportunity",
};

// Staleness threshold per stage (days since last activity, or since creation if never touched).
const STALE_THRESHOLD_DAYS: Record<string, number> = {
  NEW: 2, // matches the existing 48h "not contacted" alert
  CONTACTED: 14,
  NURTURING: 30, // the real diagnostic's headline finding
  QUALIFIED: 14, // matches the Real Opportunity gate's own 14-day activity rule
  REAL_OPPORTUNITY: 14,
};

export async function getNurturePipeline() {
  const leads = await prisma.lead.findMany({
    where: { deletedAt: null, status: { in: [...NURTURE_STAGES] } },
    select: {
      id: true,
      status: true,
      createdAt: true,
      bantScore: true,
      customer: { select: { firstName: true, lastName: true } },
      assignedTo: { select: { firstName: true, lastName: true } },
      activities: { select: { occurredAt: true }, orderBy: { occurredAt: "desc" }, take: 1 },
    },
    orderBy: { createdAt: "desc" },
  });

  const now = Date.now();

  return leads.map((l) => {
    const lastActivityAt = l.activities[0]?.occurredAt ?? l.createdAt;
    const daysSinceActivity = Math.floor((now - lastActivityAt.getTime()) / 86400000);
    const threshold = STALE_THRESHOLD_DAYS[l.status] ?? 14;
    return {
      id: l.id,
      status: l.status,
      customerName: `${l.customer.firstName} ${l.customer.lastName}`,
      assignedToName: l.assignedTo ? `${l.assignedTo.firstName} ${l.assignedTo.lastName}` : "Unassigned",
      bantScore: l.bantScore,
      daysSinceActivity,
      isStale: daysSinceActivity >= threshold,
      staleThresholdDays: threshold,
    };
  });
}

export type NurtureLeadRow = Awaited<ReturnType<typeof getNurturePipeline>>[number];

// Per-rep active book size — the real diagnostic shows conversion collapses past ~40 active
// leads per rep. Surfaced as a KPI + over-capacity flag, not enforced (no auto-routing built).
export const REP_BOOK_SIZE_CAP = 40;

export async function getRepBookSizes() {
  const grouped = await prisma.lead.groupBy({
    by: ["assignedToId"],
    where: { deletedAt: null, assignedToId: { not: null }, status: { in: [...NURTURE_STAGES] } },
    _count: { _all: true },
  });

  const users = await prisma.user.findMany({
    where: { id: { in: grouped.map((g) => g.assignedToId).filter((id): id is string => !!id) } },
    select: { id: true, firstName: true, lastName: true },
  });
  const nameById = new Map(users.map((u) => [u.id, `${u.firstName} ${u.lastName}`]));

  return grouped
    .map((g) => ({
      userId: g.assignedToId as string,
      name: nameById.get(g.assignedToId as string) ?? "Unknown",
      activeLeads: g._count._all,
      overCapacity: g._count._all > REP_BOOK_SIZE_CAP,
    }))
    .sort((a, b) => b.activeLeads - a.activeLeads);
}
