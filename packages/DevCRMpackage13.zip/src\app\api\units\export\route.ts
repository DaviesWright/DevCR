import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { toCsv } from "@/lib/csv";

export async function GET() {
  const units = await prisma.unit.findMany({
    where: { deletedAt: null },
    orderBy: [{ development: { name: "asc" } }, { unitNumber: "asc" }],
    include: {
      development: { select: { name: true, projectCode: true } },
      block: { select: { name: true } },
      propertyType: { select: { name: true, bedrooms: true, bathrooms: true } },
    },
  });

  const headers = [
    "development",
    "projectCode",
    "block",
    "unitNumber",
    "propertyType",
    "bedrooms",
    "bathrooms",
    "currentPrice",
    "currency",
    "status",
  ];
  const rows = units.map((u) => [
    u.development.name,
    u.development.projectCode,
    u.block?.name ?? "",
    u.unitNumber,
    u.propertyType.name,
    u.propertyType.bedrooms,
    u.propertyType.bathrooms,
    Number(u.currentPrice),
    u.currency,
    u.status,
  ]);

  const csv = toCsv(headers, rows);
  return new NextResponse(csv, {
    headers: {
      "Content-Type": "text/csv; charset=utf-8",
      "Content-Disposition": `attachment; filename="units-export-${new Date().toISOString().slice(0, 10)}.csv"`,
    },
  });
}
