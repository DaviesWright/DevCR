"use server";

import { revalidatePath } from "next/cache";
import { prisma } from "@/lib/prisma";
import { logAudit } from "@/lib/audit";
import { MAX_RESERVATION_DAYS } from "@/lib/queries/sales";
import { awardPoints, SALES_POINTS, evaluateAndAwardBadges } from "@/lib/gamification";

// Default probability per stage, applied whenever a card is dragged to a new
// column — keeps the weighted-pipeline KPI meaningful without manual upkeep.
const STAGE_PROBABILITY: Record<string, number> = {
  PROSPECTING: 10,
  QUALIFIED: 25,
  SITE_VISIT: 40,
  RESERVATION: 55,
  NEGOTIATION: 70,
  CONTRACT: 85,
  CLOSED_WON: 100,
  CLOSED_LOST: 0,
};

export async function moveOpportunityStage(opportunityId: string, stage: string) {
  const opportunity = await prisma.opportunity.update({
    where: { id: opportunityId },
    data: {
      stage: stage as never,
      probability: STAGE_PROBABILITY[stage] ?? undefined,
      closedAt: stage === "CLOSED_WON" || stage === "CLOSED_LOST" ? new Date() : null,
    },
  });

  if (stage === "CONTRACT") {
    await awardPoints(opportunity.ownerId, SALES_POINTS.CONTRACT_STAGE, "Deal reached Contract stage", "CONTRACT");
  }

  // Closing won creates the Sale + a PENDING commission for the owning agent,
  // exactly once per opportunity (Sale.opportunityId is unique) — a card
  // dragged back and forth across CLOSED_WON never duplicates either record.
  if (stage === "CLOSED_WON" && opportunity.unitId) {
    const existingSale = await prisma.sale.findUnique({ where: { opportunityId } });
    if (!existingSale) {
      const sale = await prisma.sale.create({
        data: {
          opportunityId,
          unitId: opportunity.unitId,
          customerId: opportunity.customerId,
          salePrice: opportunity.expectedValue,
          currency: opportunity.currency,
          status: "ACTIVE",
        },
      });
      await prisma.unit.update({ where: { id: opportunity.unitId }, data: { status: "SOLD" } });

      const agent = await prisma.salesAgent.findUnique({ where: { userId: opportunity.ownerId } });
      if (agent) {
        const amount = (Number(opportunity.expectedValue) * Number(agent.commissionRate)) / 100;
        await prisma.commission.create({
          data: { saleId: sale.id, agentId: agent.id, amount, currency: opportunity.currency, status: "PENDING" },
        });
      }

      // Sales Playbook §6.2: the internal handover notification to CX fires the
      // moment the deal is Won, addressed to whoever picks it up as CX lead.
      await prisma.clientHandover.create({
        data: {
          saleId: sale.id,
          customerId: opportunity.customerId,
          consultantId: opportunity.ownerId,
        },
      });

      await awardPoints(opportunity.ownerId, SALES_POINTS.CLOSED_WON, "Deal closed won", "CLOSED_WON");
      await evaluateAndAwardBadges(opportunity.ownerId);
    }
  }

  revalidatePath("/sales");
  revalidatePath("/sales/commissions");
  revalidatePath("/cx/handoffs");
}

// Simulated document generation (Sales Team Memorandum issue #7) — no DocuSign/PandaDoc
// integration exists, so this creates the real Reservation record (fee + expiry) that a
// document would otherwise be generated from, and logs it as an Interaction against the
// Opportunity, rather than silently doing nothing.
export async function generateReservationForm(opportunityId: string, actorId: string) {
  const opportunity = await prisma.opportunity.findUniqueOrThrow({
    where: { id: opportunityId },
    select: { unitId: true, customerId: true, expectedValue: true, currency: true },
  });
  if (!opportunity.unitId) throw new Error("Select a unit before generating a Reservation Form.");

  const existing = await prisma.reservation.findFirst({ where: { opportunityId } });
  if (existing) return { reservationId: existing.id };

  const reservationFee = Math.round(Number(opportunity.expectedValue) * 0.1);
  const expiryDate = new Date(Date.now() + MAX_RESERVATION_DAYS * 86400000);

  const reservation = await prisma.reservation.create({
    data: {
      opportunityId,
      unitId: opportunity.unitId,
      customerId: opportunity.customerId,
      reservationFee,
      currency: opportunity.currency,
      expiryDate,
      status: "ACTIVE",
    },
  });
  await prisma.unit.update({ where: { id: opportunity.unitId }, data: { status: "RESERVED" } });
  await prisma.unitStatusHistory.create({
    data: { unitId: opportunity.unitId, fromStatus: "AVAILABLE", toStatus: "RESERVED", changedById: actorId, notes: "Reservation Form generated from the Opportunity pipeline." },
  });

  await prisma.interaction.create({
    data: {
      type: "NOTE",
      subject: "Reservation Form generated",
      notes: `Reservation Form generated (simulated — no document-generation provider configured). Fee: ${reservationFee} ${opportunity.currency}. Expires in ${MAX_RESERVATION_DAYS} days (${expiryDate.toDateString()}).`,
      userId: actorId,
      relatedEntityType: "OPPORTUNITY",
      relatedEntityId: opportunityId,
    },
  });
  await logAudit(actorId, "CREATE", "Reservation", reservation.id, { unitId: opportunity.unitId, expiryDate: expiryDate.toISOString() });
  await awardPoints(actorId, SALES_POINTS.RESERVATION_MADE, "Reservation Form generated", "RESERVATION");

  revalidatePath("/sales");
  revalidatePath("/projects");
  return { reservationId: reservation.id };
}

// Direct unit-hold entry point (Projects inventory) — for a potential/qualified customer who
// doesn't have an Opportunity yet. Same 5-day cap and unit-status transition as the pipeline's
// Reservation Form; both funnel through the same Reservation/UnitStatusHistory records so a
// unit's hold history reads the same regardless of where it was created.
export async function reserveUnit(input: { unitId: string; leadId: string; days: number; actorId: string }) {
  const unit = await prisma.unit.findUniqueOrThrow({
    where: { id: input.unitId },
    select: { id: true, status: true, currentPrice: true, currency: true },
  });
  if (unit.status !== "AVAILABLE") throw new Error("Only an available unit can be reserved.");

  const lead = await prisma.lead.findUniqueOrThrow({
    where: { id: input.leadId },
    select: { customerId: true, customer: { select: { firstName: true, lastName: true } } },
  });

  const days = Math.min(Math.max(Math.round(input.days), 1), MAX_RESERVATION_DAYS);
  const reservationFee = Math.round(Number(unit.currentPrice) * 0.1);
  const expiryDate = new Date(Date.now() + days * 86400000);

  const reservation = await prisma.reservation.create({
    data: {
      unitId: unit.id,
      customerId: lead.customerId,
      reservationFee,
      currency: unit.currency,
      expiryDate,
      status: "ACTIVE",
    },
  });
  await prisma.unit.update({ where: { id: unit.id }, data: { status: "RESERVED" } });
  await prisma.unitStatusHistory.create({
    data: {
      unitId: unit.id,
      fromStatus: "AVAILABLE",
      toStatus: "RESERVED",
      changedById: input.actorId,
      notes: `Reserved for ${lead.customer.firstName} ${lead.customer.lastName} — ${days}-day hold, expires ${expiryDate.toDateString()}.`,
    },
  });
  await prisma.interaction.create({
    data: {
      type: "NOTE",
      subject: "Unit reserved",
      notes: `Held for ${days} day${days === 1 ? "" : "s"} (max ${MAX_RESERVATION_DAYS}). Fee: ${reservationFee} ${unit.currency}. Expires ${expiryDate.toDateString()}.`,
      userId: input.actorId,
      relatedEntityType: "UNIT",
      relatedEntityId: unit.id,
    },
  });
  await logAudit(input.actorId, "CREATE", "Reservation", reservation.id, { unitId: unit.id, days, expiryDate: expiryDate.toISOString() });
  await awardPoints(input.actorId, SALES_POINTS.RESERVATION_MADE, "Unit reserved", "RESERVATION");

  revalidatePath("/projects");
  revalidatePath("/sales");
  return { reservationId: reservation.id };
}

export async function cancelReservation(reservationId: string, actorId: string) {
  const reservation = await prisma.reservation.findUniqueOrThrow({
    where: { id: reservationId },
    select: { unitId: true, status: true },
  });
  if (reservation.status !== "ACTIVE") return;

  await prisma.reservation.update({ where: { id: reservationId }, data: { status: "CANCELLED" } });
  await prisma.unit.update({ where: { id: reservation.unitId }, data: { status: "AVAILABLE" } });
  await prisma.unitStatusHistory.create({
    data: { unitId: reservation.unitId, fromStatus: "RESERVED", toStatus: "AVAILABLE", changedById: actorId, notes: "Reservation cancelled." },
  });
  await logAudit(actorId, "CANCEL", "Reservation", reservationId, { unitId: reservation.unitId });

  revalidatePath("/projects");
  revalidatePath("/sales");
}

// No background scheduler exists in this app (established convention — see docs/backlog.md
// §4), so an expired-but-still-ACTIVE hold is released lazily: computed for display in
// getUnitsInventory, and swept for real here when a rep clicks "Release Expired Holds".
export async function releaseExpiredReservations(actorId: string) {
  const expired = await prisma.reservation.findMany({
    where: { status: "ACTIVE", expiryDate: { lt: new Date() } },
    select: { id: true, unitId: true },
  });

  for (const r of expired) {
    await prisma.reservation.update({ where: { id: r.id }, data: { status: "EXPIRED" } });
    await prisma.unit.updateMany({ where: { id: r.unitId, status: "RESERVED" }, data: { status: "AVAILABLE" } });
    await prisma.unitStatusHistory.create({
      data: { unitId: r.unitId, fromStatus: "RESERVED", toStatus: "AVAILABLE", changedById: actorId, notes: `Reservation expired — ${MAX_RESERVATION_DAYS}-day hold not converted.` },
    });
    await logAudit(actorId, "EXPIRE", "Reservation", r.id, { unitId: r.unitId });
  }

  revalidatePath("/projects");
  revalidatePath("/sales");
  return { releasedCount: expired.length };
}
