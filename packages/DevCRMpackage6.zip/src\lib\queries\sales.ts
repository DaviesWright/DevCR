import { prisma } from "@/lib/prisma";

// Sales Team Memorandum unit-hold policy: a unit reservation may never exceed 5 days without
// a signed SPA/contract behind it. Shared by both reservation entry points (the Opportunity
// pipeline's "Generate Reservation Form" and the Projects inventory's "Reserve Unit").
export const MAX_RESERVATION_DAYS = 5;

export const PIPELINE_STAGES = [
  "PROSPECTING",
  "QUALIFIED",
  "SITE_VISIT",
  "RESERVATION",
  "NEGOTIATION",
  "CONTRACT",
  "CLOSED_WON",
  "CLOSED_LOST",
] as const;

export const STAGE_LABEL: Record<string, string> = {
  PROSPECTING: "Prospecting",
  QUALIFIED: "Qualified",
  SITE_VISIT: "Site Visit",
  RESERVATION: "Reservation",
  NEGOTIATION: "Negotiation",
  CONTRACT: "Contract",
  CLOSED_WON: "Closed Won",
  CLOSED_LOST: "Closed Lost",
};

export async function getPipelineKanban() {
  const opportunities = await prisma.opportunity.findMany({
    where: { deletedAt: null },
    include: {
      customer: { select: { firstName: true, lastName: true } },
      unit: { select: { unitNumber: true } },
      owner: { select: { firstName: true, lastName: true } },
      reservations: { where: { status: "ACTIVE" }, orderBy: { expiryDate: "desc" }, take: 1 },
    },
    orderBy: { updatedAt: "desc" },
  });

  const now = Date.now();

  return opportunities.map((o) => {
    const reservation = o.reservations[0] ?? null;
    return {
      id: o.id,
      stage: o.stage,
      customerId: o.customerId,
      unitId: o.unitId,
      customerName: `${o.customer.firstName} ${o.customer.lastName}`,
      unitNumber: o.unit?.unitNumber ?? null,
      expectedValue: Number(o.expectedValue),
      currency: o.currency,
      probability: o.probability,
      ownerName: `${o.owner.firstName} ${o.owner.lastName}`,
      updatedAt: o.updatedAt,
      hasReservation: !!reservation,
      reservation: reservation ? { expiryDate: reservation.expiryDate, expired: reservation.expiryDate.getTime() < now } : null,
    };
  });
}

export type PipelineCard = Awaited<ReturnType<typeof getPipelineKanban>>[number];

export async function getPipelineKpis() {
  const opportunities = await prisma.opportunity.findMany({
    where: { deletedAt: null },
    select: { stage: true, expectedValue: true, probability: true },
  });

  const open = opportunities.filter((o) => o.stage !== "CLOSED_WON" && o.stage !== "CLOSED_LOST");
  const won = opportunities.filter((o) => o.stage === "CLOSED_WON");
  const lost = opportunities.filter((o) => o.stage === "CLOSED_LOST");
  const closed = won.length + lost.length;

  const pipelineValue = open.reduce((sum, o) => sum + Number(o.expectedValue), 0);
  const weightedPipeline = open.reduce((sum, o) => sum + (Number(o.expectedValue) * o.probability) / 100, 0);
  const winRate = closed ? (won.length / closed) * 100 : 0;
  const avgDealSize = open.length ? pipelineValue / open.length : 0;

  return { pipelineValue, weightedPipeline, winRate, avgDealSize, openCount: open.length };
}

export async function getUnitsInventory() {
  const units = await prisma.unit.findMany({
    where: { deletedAt: null },
    include: {
      development: { select: { id: true, name: true, projectCode: true, totalUnits: true } },
      propertyType: { select: { name: true, bedrooms: true } },
      reservations: {
        where: { status: "ACTIVE" },
        orderBy: { expiryDate: "desc" },
        take: 1,
        include: { customer: { select: { firstName: true, lastName: true } } },
      },
    },
    orderBy: [{ development: { name: "asc" } }, { unitNumber: "asc" }],
  });

  const now = Date.now();

  return units.map((u) => {
    const reservation = u.reservations[0] ?? null;
    const expired = reservation ? reservation.expiryDate.getTime() < now : false;
    return {
      id: u.id,
      unitNumber: u.unitNumber,
      developmentId: u.development.id,
      developmentName: u.development.name,
      projectCode: u.development.projectCode,
      developmentTotalUnits: u.development.totalUnits,
      propertyTypeName: u.propertyType.name,
      bedrooms: u.propertyType.bedrooms,
      currentPrice: Number(u.currentPrice),
      currency: u.currency,
      status: u.status,
      reservation: reservation
        ? {
            id: reservation.id,
            customerName: `${reservation.customer.firstName} ${reservation.customer.lastName}`,
            expiryDate: reservation.expiryDate,
            reservedAt: reservation.reservedAt,
            expired,
          }
        : null,
    };
  });
}

export type UnitInventoryRow = Awaited<ReturnType<typeof getUnitsInventory>>[number];

export async function getUnitsInventoryKpis() {
  const counts = await prisma.unit.groupBy({
    by: ["status"],
    where: { deletedAt: null },
    _count: true,
  });
  const byStatus = Object.fromEntries(counts.map((c) => [c.status, c._count])) as Record<string, number>;
  const total = counts.reduce((sum, c) => sum + c._count, 0);
  return {
    total,
    available: byStatus.AVAILABLE ?? 0,
    reserved: byStatus.RESERVED ?? 0,
    sold: byStatus.SOLD ?? 0,
  };
}

// Reservations are made against "potential / qualified customers" — a Lead that hasn't been
// disqualified or already converted — since that's the population a sales rep is actively
// working, not the full customer base.
export async function getReservableLeads() {
  const leads = await prisma.lead.findMany({
    where: { deletedAt: null, status: { notIn: ["UNQUALIFIED", "CONVERTED"] } },
    select: { id: true, customerId: true, status: true, customer: { select: { firstName: true, lastName: true } } },
    orderBy: { createdAt: "desc" },
  });
  return leads.map((l) => ({
    leadId: l.id,
    customerId: l.customerId,
    status: l.status,
    label: `${l.customer.firstName} ${l.customer.lastName} — ${l.status.replace(/_/g, " ")}`,
  }));
}
