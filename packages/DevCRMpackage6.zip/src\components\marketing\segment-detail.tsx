"use client";

import * as React from "react";
import { useRouter } from "next/navigation";
import { Loader2, RefreshCw, UserMinus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { refreshMarketingSegment, removeCustomerFromSegment } from "@/lib/actions/marketing";
import { relativeTime, orEmpty } from "@/lib/utils";
import type { getMarketingSegmentDetail } from "@/lib/queries/marketing";

type SegmentDetail = NonNullable<Awaited<ReturnType<typeof getMarketingSegmentDetail>>>;

export function SegmentDetailView({ segment }: { segment: SegmentDetail }) {
  const router = useRouter();
  const [pending, setPending] = React.useState(false);

  async function refresh() {
    setPending(true);
    await refreshMarketingSegment(segment.id);
    router.refresh();
    setPending(false);
  }

  async function remove(customerId: string) {
    await removeCustomerFromSegment(segment.id, customerId);
    router.refresh();
  }

  const criteriaEntries = Object.entries(segment.criteria).filter(([, v]) => v !== undefined && v !== "");

  return (
    <div className="flex flex-col gap-4">
      <div className="flex flex-wrap items-center justify-between gap-3 rounded-lg border border-border p-4">
        <div>
          <p className="text-sm text-muted-foreground">
            {segment.lastComputedAt ? `Last refreshed ${relativeTime(segment.lastComputedAt)}` : "Not yet computed"}
            {segment.createdBy ? ` · Created by ${segment.createdBy}` : ""}
          </p>
          {criteriaEntries.length > 0 && (
            <div className="mt-2 flex flex-wrap gap-1.5">
              {criteriaEntries.map(([key, value]) => (
                <Badge key={key} variant="outline">
                  {key.replace(/([A-Z])/g, " $1").toLowerCase()}: {String(value)}
                </Badge>
              ))}
            </div>
          )}
        </div>
        <Button variant="outline" size="sm" onClick={refresh} disabled={pending}>
          {pending ? <Loader2 className="size-3.5 animate-spin" /> : <RefreshCw className="size-3.5" />} Refresh
        </Button>
      </div>

      {(segment.campaigns.length > 0 || segment.journeys.length > 0) && (
        <div className="flex flex-wrap gap-2 text-xs text-muted-foreground">
          {segment.campaigns.length > 0 && <span>Used by {segment.campaigns.length} campaign(s)</span>}
          {segment.journeys.length > 0 && <span>Used by {segment.journeys.length} journey(s)</span>}
        </div>
      )}

      <div className="rounded-lg border border-border">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Customer</TableHead>
              <TableHead>Segment</TableHead>
              <TableHead>Engagement</TableHead>
              <TableHead>Added</TableHead>
              <TableHead className="w-10" />
            </TableRow>
          </TableHeader>
          <TableBody>
            {segment.members.length === 0 ? (
              <TableRow>
                <TableCell colSpan={5} className="py-10 text-center text-sm text-muted-foreground">
                  No members yet.
                </TableCell>
              </TableRow>
            ) : (
              segment.members.map((m) => (
                <TableRow key={m.id}>
                  <TableCell>
                    <p className="text-sm font-medium text-foreground">{m.customer.name}</p>
                    <p className="text-xs text-muted-foreground">{orEmpty(m.customer.email)}</p>
                  </TableCell>
                  <TableCell className="text-sm">{orEmpty(m.customer.segment)}</TableCell>
                  <TableCell className="text-sm tabular-nums">{m.customer.engagementScore}</TableCell>
                  <TableCell className="text-sm text-muted-foreground">
                    {relativeTime(m.addedAt)} {m.manuallyAdded && <Badge variant="outline">manual</Badge>}
                  </TableCell>
                  <TableCell>
                    <Button variant="ghost" size="sm" onClick={() => remove(m.customer.id)} title="Remove from segment">
                      <UserMinus className="size-3.5 text-destructive" />
                    </Button>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}
