import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { CustomersTable } from "@/components/customers/customers-table";
import { TopPurchasers } from "@/components/customers/top-purchasers";
import { getCustomersList, getTopPurchasers } from "@/lib/queries/customers";

export default async function CustomersPage() {
  const [customers, topPurchasers] = await Promise.all([getCustomersList(), getTopPurchasers()]);

  return (
    <div className="flex flex-col gap-6">
      <div>
        <h1 className="font-heading text-2xl font-semibold">Customers</h1>
        <p className="text-sm text-muted-foreground">{customers.length} customers — unified profile across leads, sales, and support.</p>
      </div>

      <Tabs defaultValue="all">
        <TabsList>
          <TabsTrigger value="all">All Customers ({customers.length})</TabsTrigger>
          <TabsTrigger value="top">Top Purchasers ({topPurchasers.length})</TabsTrigger>
        </TabsList>
        <TabsContent value="all">
          <CustomersTable customers={customers} />
        </TabsContent>
        <TabsContent value="top">
          <p className="mb-3 text-sm text-muted-foreground">
            Ranked by lifetime confirmed-sale value across all developments. Platinum &gt;$1M · Prestige
            $500K–$1M · Executive $200K–$499,999 · Premium &lt;$200K.
          </p>
          <TopPurchasers purchasers={topPurchasers} />
        </TabsContent>
      </Tabs>
    </div>
  );
}
