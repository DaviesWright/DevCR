import Link from "next/link";
import { ArrowLeft, Clock3, BadgeCheck, Wallet, AlertTriangle } from "lucide-react";
import { KpiCard } from "@/components/dashboard/kpi-card";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { CommissionsTable } from "@/components/sales/commissions-table";
import { getCommissionsList, getCommissionKpis, getAgentCommissionSummary } from "@/lib/queries/commissions";
import { formatCurrency } from "@/lib/utils";

export default async function CommissionsPage() {
  const [commissions, kpis, agentSummary] = await Promise.all([
    getCommissionsList(),
    getCommissionKpis(),
    getAgentCommissionSummary(),
  ]);

  return (
    <div className="flex flex-col gap-6">
      <Link href="/sales" className="flex w-fit items-center gap-1 text-sm text-muted-foreground hover:text-foreground">
        <ArrowLeft className="size-4" /> Back to Sales Pipeline
      </Link>

      <div>
        <h1 className="font-heading text-2xl font-semibold">Commissions</h1>
        <p className="text-sm text-muted-foreground">
          Auto-created when a deal is closed won. SLA: process by day 5, escalate day 6, escalate Finance day 8.
        </p>
      </div>

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <KpiCard title="Pending" value={formatCurrency(kpis.pendingAmount)} icon={Clock3} tone="warning" />
        <KpiCard title="Approved" value={formatCurrency(kpis.approvedAmount)} icon={BadgeCheck} tone="info" />
        <KpiCard title="Paid this month" value={formatCurrency(kpis.paidThisMonthAmount)} icon={Wallet} tone="success" />
        <KpiCard title="SLA overdue" value={String(kpis.overdueCount)} icon={AlertTriangle} tone="destructive" />
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Agent summary</CardTitle>
        </CardHeader>
        <CardContent className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {agentSummary.map((a) => (
            <div key={a.agentId} className="rounded-md bg-muted px-3 py-2.5">
              <p className="text-sm font-medium text-foreground">
                {a.name} <span className="text-xs text-muted-foreground">({a.agentCode})</span>
              </p>
              <div className="mt-1.5 flex flex-wrap gap-x-4 gap-y-0.5 text-xs text-muted-foreground">
                <span>Pending {formatCurrency(a.pendingAmount)}</span>
                <span>Approved {formatCurrency(a.approvedAmount)}</span>
                <span>Paid {formatCurrency(a.paidAmount)}</span>
              </div>
            </div>
          ))}
        </CardContent>
      </Card>

      <CommissionsTable commissions={commissions} />
    </div>
  );
}
