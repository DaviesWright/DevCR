import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { EmailIntegrations } from "@/components/admin/email-integrations";
import { WorkflowsPanel } from "@/components/admin/workflows-panel";
import { RolesOverview } from "@/components/admin/roles-overview";
import { getEmailConnectionsForUser } from "@/lib/actions/integrations";
import { getWorkflows, getRecentWorkflowRuns, getWebhooks } from "@/lib/queries/workflows";
import { getRolesOverview } from "@/lib/queries/roles";
import { getCurrentUser } from "@/lib/queries/reference";
import { isGoogleConfigured, isMicrosoftConfigured } from "@/lib/integrations/config";

export default async function AdminPage() {
  const currentUser = await getCurrentUser();
  const [connections, workflows, runs, webhooks, roles] = await Promise.all([
    getEmailConnectionsForUser(currentUser.id),
    getWorkflows(),
    getRecentWorkflowRuns(),
    getWebhooks(),
    getRolesOverview(),
  ]);

  return (
    <div className="flex flex-col gap-6">
      <div>
        <h1 className="font-heading text-2xl font-semibold">Admin</h1>
        <p className="text-sm text-muted-foreground">Workspace and integration settings.</p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Email &amp; calendar sync</CardTitle>
        </CardHeader>
        <CardContent className="flex flex-col gap-3">
          <p className="text-sm text-muted-foreground">
            Connect your own Gmail or Outlook account to pull your real sent/received emails and calendar events into
            each customer's timeline — no more re-typing what you already sent. Sync is on-demand ("Sync now") since
            this app has no public URL for a real-time push subscription.
          </p>
          <EmailIntegrations
            connections={connections}
            googleConfigured={isGoogleConfigured()}
            microsoftConfigured={isMicrosoftConfigured()}
          />
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Workflow automation</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="mb-4 text-sm text-muted-foreground">
            "When X happens, do Y" — across Leads, Opportunities, Complaints, and Sales, not just Marketing segments.
            Fires in real time off real CRM events (no schedule). A step can create a task, log a note, or call an
            external webhook.
          </p>
          <WorkflowsPanel workflows={workflows} runs={runs} webhooks={webhooks} currentUserId={currentUser.id} />
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Roles &amp; permissions</CardTitle>
        </CardHeader>
        <CardContent className="flex flex-col gap-3">
          <p className="text-sm text-muted-foreground">
            The 24 roles from the Devtraco CRM Roles &amp; Permissions Specification — data scope controls which
            records a role can see/edit (Own → Team → Department → All → System), report scope controls which
            reports, and read-only roles (Executives) never get a write action. Switch accounts (top right) to see
            these enforced live — try Group Chief Executive Officer, Client Experience Officer, or Sales Agent.
          </p>
          <RolesOverview roles={roles} />
        </CardContent>
      </Card>
    </div>
  );
}
