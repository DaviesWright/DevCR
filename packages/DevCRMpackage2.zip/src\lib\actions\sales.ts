"use server";

import { revalidatePath } from "next/cache";
import { prisma } from "@/lib/prisma";

// Default probability per stage, applied whenever a card is dragged to a new
// column — keeps the weighted-pipeline KPI meaningful without manual upkeep.
const STAGE_PROBABILITY: Record<string, number> = {
  PROSPECTING: 10,
  QUALIFIED: 25,
  SITE_VISIT: 40,
  RESERVATION: 55,
  NEGOTIATION: 70,
  CONTRACT: 85,
  CLOSED_WON: 100,
  CLOSED_LOST: 0,
};

export async function moveOpportunityStage(opportunityId: string, stage: string) {
  const opportunity = await prisma.opportunity.update({
    where: { id: opportunityId },
    data: {
      stage: stage as never,
      probability: STAGE_PROBABILITY[stage] ?? undefined,
      closedAt: stage === "CLOSED_WON" || stage === "CLOSED_LOST" ? new Date() : null,
    },
  });

  // Closing won creates the Sale + a PENDING commission for the owning agent,
  // exactly once per opportunity (Sale.opportunityId is unique) — a card
  // dragged back and forth across CLOSED_WON never duplicates either record.
  if (stage === "CLOSED_WON" && opportunity.unitId) {
    const existingSale = await prisma.sale.findUnique({ where: { opportunityId } });
    if (!existingSale) {
      const sale = await prisma.sale.create({
        data: {
          opportunityId,
          unitId: opportunity.unitId,
          customerId: opportunity.customerId,
          salePrice: opportunity.expectedValue,
          currency: opportunity.currency,
          status: "ACTIVE",
        },
      });
      await prisma.unit.update({ where: { id: opportunity.unitId }, data: { status: "SOLD" } });

      const agent = await prisma.salesAgent.findUnique({ where: { userId: opportunity.ownerId } });
      if (agent) {
        const amount = (Number(opportunity.expectedValue) * Number(agent.commissionRate)) / 100;
        await prisma.commission.create({
          data: { saleId: sale.id, agentId: agent.id, amount, currency: opportunity.currency, status: "PENDING" },
        });
      }

      // Sales Playbook §6.2: the internal handover notification to CX fires the
      // moment the deal is Won, addressed to whoever picks it up as CX lead.
      await prisma.clientHandover.create({
        data: {
          saleId: sale.id,
          customerId: opportunity.customerId,
          consultantId: opportunity.ownerId,
        },
      });
    }
  }

  revalidatePath("/sales");
  revalidatePath("/sales/commissions");
  revalidatePath("/cx/handoffs");
}

// Simulated document generation (Sales Team Memorandum issue #7) — no DocuSign/PandaDoc
// integration exists, so this creates the real Reservation record (fee + expiry) that a
// document would otherwise be generated from, and logs it as an Interaction against the
// Opportunity, rather than silently doing nothing.
export async function generateReservationForm(opportunityId: string, actorId: string) {
  const opportunity = await prisma.opportunity.findUniqueOrThrow({
    where: { id: opportunityId },
    select: { unitId: true, customerId: true, expectedValue: true, currency: true },
  });
  if (!opportunity.unitId) throw new Error("Select a unit before generating a Reservation Form.");

  const existing = await prisma.reservation.findFirst({ where: { opportunityId } });
  if (existing) return { reservationId: existing.id };

  const reservationFee = Math.round(Number(opportunity.expectedValue) * 0.1);
  const expiryDate = new Date(Date.now() + 14 * 86400000);

  const reservation = await prisma.reservation.create({
    data: {
      opportunityId,
      unitId: opportunity.unitId,
      customerId: opportunity.customerId,
      reservationFee,
      currency: opportunity.currency,
      expiryDate,
      status: "ACTIVE",
    },
  });

  await prisma.interaction.create({
    data: {
      type: "NOTE",
      subject: "Reservation Form generated",
      notes: `Reservation Form generated (simulated — no document-generation provider configured). Fee: ${reservationFee} ${opportunity.currency}. Expires ${expiryDate.toDateString()}.`,
      userId: actorId,
      relatedEntityType: "OPPORTUNITY",
      relatedEntityId: opportunityId,
    },
  });

  revalidatePath("/sales");
  return { reservationId: reservation.id };
}
