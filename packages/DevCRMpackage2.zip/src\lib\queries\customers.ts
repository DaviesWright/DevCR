import { prisma } from "@/lib/prisma";

export type CustomerListItem = {
  id: string;
  name: string;
  phone: string;
  email: string | null;
  segment: string | null;
  kycStatus: string;
  leadCount: number;
  saleCount: number;
  complaintCount: number;
};

export async function getCustomersList(): Promise<CustomerListItem[]> {
  const customers = await prisma.customer.findMany({
    where: { deletedAt: null },
    orderBy: { createdAt: "desc" },
    include: { _count: { select: { leads: true, sales: true, complaints: true } } },
  });
  return customers.map((c) => ({
    id: c.id,
    name: `${c.firstName} ${c.lastName}`,
    phone: c.phone,
    email: c.email,
    segment: c.segment,
    kycStatus: c.kycStatus,
    leadCount: c._count.leads,
    saleCount: c._count.sales,
    complaintCount: c._count.complaints,
  }));
}

export async function getCustomerDetail(customerId: string) {
  const customer = await prisma.customer.findUnique({
    where: { id: customerId },
    include: {
      assignedSalesRep: { select: { firstName: true, lastName: true } },
      leads: {
        select: { id: true, status: true, qualificationStatus: true, createdAt: true, source: { select: { name: true } } },
        orderBy: { createdAt: "desc" },
      },
      opportunities: {
        select: { id: true, stage: true, expectedValue: true, currency: true, unit: { select: { unitNumber: true } } },
        orderBy: { updatedAt: "desc" },
      },
      sales: {
        select: {
          id: true,
          salePrice: true,
          currency: true,
          status: true,
          saleDate: true,
          unit: { select: { unitNumber: true } },
          paymentPlan: {
            select: {
              totalAmount: true,
              downPayment: true,
              status: true,
              schedules: { select: { amountDue: true, status: true } },
            },
          },
        },
        orderBy: { saleDate: "desc" },
      },
      complaints: {
        select: { id: true, subject: true, status: true, priority: true, openedAt: true },
        orderBy: { openedAt: "desc" },
      },
      handovers: {
        select: { id: true, status: true, scheduledAt: true, completedAt: true, unit: { select: { unitNumber: true } } },
        orderBy: { createdAt: "desc" },
      },
    },
  });
  if (!customer) return null;

  const sales = customer.sales.map((s) => {
    const paid = s.paymentPlan?.schedules.filter((sch) => sch.status === "PAID").reduce((sum, sch) => sum + Number(sch.amountDue), 0) ?? 0;
    const total = s.paymentPlan ? Number(s.paymentPlan.totalAmount) : Number(s.salePrice);
    const overdueCount = s.paymentPlan?.schedules.filter((sch) => sch.status === "OVERDUE").length ?? 0;
    return {
      id: s.id,
      unitNumber: s.unit.unitNumber,
      salePrice: Number(s.salePrice),
      currency: s.currency,
      status: s.status,
      saleDate: s.saleDate,
      paymentPlanStatus: s.paymentPlan?.status ?? null,
      totalAmount: total,
      paidAmount: paid,
      balance: total - paid,
      overdueInstallments: overdueCount,
    };
  });

  return {
    id: customer.id,
    name: `${customer.firstName} ${customer.lastName}`,
    phone: customer.phone,
    email: customer.email,
    nationality: customer.nationality,
    segment: customer.segment,
    kycStatus: customer.kycStatus,
    assignedSalesRep: customer.assignedSalesRep
      ? `${customer.assignedSalesRep.firstName} ${customer.assignedSalesRep.lastName}`
      : null,
    createdAt: customer.createdAt,
    leads: customer.leads.map((l) => ({
      id: l.id,
      status: l.status,
      qualificationStatus: l.qualificationStatus,
      source: l.source.name,
      createdAt: l.createdAt,
    })),
    opportunities: customer.opportunities.map((o) => ({
      id: o.id,
      stage: o.stage,
      expectedValue: Number(o.expectedValue),
      currency: o.currency,
      unitNumber: o.unit?.unitNumber ?? null,
    })),
    sales,
    complaints: customer.complaints.map((c) => ({
      id: c.id,
      subject: c.subject,
      status: c.status,
      priority: c.priority,
      openedAt: c.openedAt,
    })),
    handovers: customer.handovers.map((h) => ({
      id: h.id,
      status: h.status,
      scheduledAt: h.scheduledAt,
      completedAt: h.completedAt,
      unitNumber: h.unit.unitNumber,
    })),
  };
}

export type CustomerDetail = NonNullable<Awaited<ReturnType<typeof getCustomerDetail>>>;
