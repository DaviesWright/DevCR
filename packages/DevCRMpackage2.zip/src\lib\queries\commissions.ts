import { prisma } from "@/lib/prisma";

// SLA tiers from the Sales Workflow Optimisation doc: process by day 5,
// escalate to Sales Manager on day 6, escalate to Finance Director on day 8.
export type SlaTier = "ON_TRACK" | "DUE_SOON" | "ESCALATE_MANAGER" | "ESCALATE_FINANCE";

function slaTier(daysPending: number): SlaTier {
  if (daysPending >= 8) return "ESCALATE_FINANCE";
  if (daysPending >= 6) return "ESCALATE_MANAGER";
  if (daysPending >= 5) return "DUE_SOON";
  return "ON_TRACK";
}

export type CommissionListItem = {
  id: string;
  saleId: string;
  unitNumber: string;
  customerName: string;
  agentName: string;
  agentCode: string;
  amount: number;
  currency: string;
  status: string;
  createdAt: Date;
  approvedAt: Date | null;
  paidAt: Date | null;
  daysPending: number;
  slaTier: SlaTier | null;
};

export async function getCommissionsList(): Promise<CommissionListItem[]> {
  const now = new Date();
  const commissions = await prisma.commission.findMany({
    orderBy: { createdAt: "desc" },
    include: {
      sale: { select: { unit: { select: { unitNumber: true } }, customer: { select: { firstName: true, lastName: true } } } },
      agent: { select: { agentCode: true, user: { select: { firstName: true, lastName: true } } } },
    },
  });
  return commissions.map((c) => {
    const daysPending = Math.floor((now.getTime() - c.createdAt.getTime()) / 86400000);
    const isSettled = c.status === "PAID" || c.status === "VOID";
    return {
      id: c.id,
      saleId: c.saleId,
      unitNumber: c.sale.unit.unitNumber,
      customerName: `${c.sale.customer.firstName} ${c.sale.customer.lastName}`,
      agentName: `${c.agent.user.firstName} ${c.agent.user.lastName}`,
      agentCode: c.agent.agentCode,
      amount: Number(c.amount),
      currency: c.currency,
      status: c.status,
      createdAt: c.createdAt,
      approvedAt: c.approvedAt,
      paidAt: c.paidAt,
      daysPending,
      slaTier: isSettled ? null : slaTier(daysPending),
    };
  });
}

export async function getCommissionKpis() {
  const commissions = await prisma.commission.findMany({
    select: { amount: true, status: true, createdAt: true, paidAt: true },
  });
  const now = new Date();
  const monthStart = new Date(now.getFullYear(), now.getMonth(), 1);

  const pending = commissions.filter((c) => c.status === "PENDING");
  const approved = commissions.filter((c) => c.status === "APPROVED");
  const paidThisMonth = commissions.filter((c) => c.status === "PAID" && c.paidAt && c.paidAt >= monthStart);
  const overdue = commissions.filter((c) => {
    if (c.status !== "PENDING" && c.status !== "APPROVED") return false;
    const daysPending = Math.floor((now.getTime() - c.createdAt.getTime()) / 86400000);
    return daysPending >= 6;
  });

  return {
    pendingAmount: pending.reduce((sum, c) => sum + Number(c.amount), 0),
    approvedAmount: approved.reduce((sum, c) => sum + Number(c.amount), 0),
    paidThisMonthAmount: paidThisMonth.reduce((sum, c) => sum + Number(c.amount), 0),
    overdueCount: overdue.length,
  };
}

export type AgentSummary = {
  agentId: string;
  agentCode: string;
  name: string;
  pendingAmount: number;
  approvedAmount: number;
  paidAmount: number;
  commissionCount: number;
};

export async function getAgentCommissionSummary(): Promise<AgentSummary[]> {
  const agents = await prisma.salesAgent.findMany({
    where: { isActive: true },
    include: {
      user: { select: { firstName: true, lastName: true } },
      commissions: { select: { amount: true, status: true } },
    },
    orderBy: { agentCode: "asc" },
  });
  return agents.map((a) => ({
    agentId: a.id,
    agentCode: a.agentCode,
    name: `${a.user.firstName} ${a.user.lastName}`,
    pendingAmount: a.commissions.filter((c) => c.status === "PENDING").reduce((sum, c) => sum + Number(c.amount), 0),
    approvedAmount: a.commissions.filter((c) => c.status === "APPROVED").reduce((sum, c) => sum + Number(c.amount), 0),
    paidAmount: a.commissions.filter((c) => c.status === "PAID").reduce((sum, c) => sum + Number(c.amount), 0),
    commissionCount: a.commissions.length,
  }));
}
