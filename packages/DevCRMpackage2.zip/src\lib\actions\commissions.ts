"use server";

import { revalidatePath } from "next/cache";
import { prisma } from "@/lib/prisma";

function revalidateCommissions() {
  revalidatePath("/sales/commissions");
}

export async function approveCommission(commissionId: string) {
  await prisma.commission.update({
    where: { id: commissionId },
    data: { status: "APPROVED", approvedAt: new Date() },
  });
  revalidateCommissions();
}

export async function markCommissionPaid(commissionId: string) {
  await prisma.commission.update({
    where: { id: commissionId },
    data: { status: "PAID", paidAt: new Date() },
  });
  revalidateCommissions();
}

export async function voidCommission(commissionId: string) {
  await prisma.commission.update({
    where: { id: commissionId },
    data: { status: "VOID" },
  });
  revalidateCommissions();
}
