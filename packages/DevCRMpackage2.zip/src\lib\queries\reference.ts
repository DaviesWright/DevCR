import { cookies } from "next/headers";
import { prisma } from "@/lib/prisma";

const USER_SELECT = {
  id: true,
  firstName: true,
  lastName: true,
  role: { select: { name: true } },
} as const;

// Lightweight interim auth: no passwords or sessions, but "who you're acting as" is a real
// per-browser cookie set via setActingUser, not a hardcoded user. Falls back to the first
// seeded user when no cookie is set (e.g. a fresh browser). isManager gates the handful of
// ownership-restricted actions (see lead-actions.tsx / leads/[id]/page.tsx).
export async function getCurrentUser() {
  const actingId = cookies().get("acting_user_id")?.value;

  const acting = actingId
    ? await prisma.user.findFirst({ where: { id: actingId, deletedAt: null, isActive: true }, select: USER_SELECT })
    : null;

  const user =
    acting ??
    (await prisma.user.findFirst({
      where: { deletedAt: null },
      orderBy: { createdAt: "asc" },
      select: USER_SELECT,
    }));

  if (!user) throw new Error("No users exist — run the seed script first.");
  return {
    id: user.id,
    name: `${user.firstName} ${user.lastName}`,
    roleName: user.role?.name ?? null,
    isManager: /manager|director|admin/i.test(user.role?.name ?? ""),
  };
}

export async function getAssignableUsers() {
  const users = await prisma.user.findMany({
    where: { isActive: true, deletedAt: null },
    select: { id: true, firstName: true, lastName: true },
    orderBy: { firstName: "asc" },
  });
  return users.map((u) => ({ id: u.id, name: `${u.firstName} ${u.lastName}` }));
}

export async function getLeadSources() {
  const sources = await prisma.leadSource.findMany({
    where: { isActive: true },
    select: { id: true, name: true },
    orderBy: { name: "asc" },
  });
  return sources;
}

export async function getCampaigns() {
  const campaigns = await prisma.campaign.findMany({
    where: { status: { in: ["PLANNED", "ACTIVE"] } },
    select: { id: true, name: true },
    orderBy: { name: "asc" },
  });
  return campaigns;
}

export async function getPropertyTypes() {
  const types = await prisma.propertyType.findMany({
    select: { id: true, name: true },
    orderBy: { name: "asc" },
  });
  return types;
}

export async function getAvailableUnitsForConversion() {
  const units = await prisma.unit.findMany({
    where: { status: { in: ["AVAILABLE", "RESERVED"] }, deletedAt: null },
    select: { id: true, unitNumber: true, currentPrice: true, currency: true, status: true },
    orderBy: { unitNumber: "asc" },
    take: 100,
  });
  return units.map((u) => ({
    id: u.id,
    unitNumber: u.unitNumber,
    currentPrice: Number(u.currentPrice),
    currency: u.currency,
    status: u.status,
  }));
}
