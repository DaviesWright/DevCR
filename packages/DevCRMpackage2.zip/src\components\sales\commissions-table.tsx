"use client";

import * as React from "react";
import { useRouter } from "next/navigation";
import { Loader2, CheckCircle2, DollarSign, Ban } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { approveCommission, markCommissionPaid, voidCommission } from "@/lib/actions/commissions";
import { formatCurrency, formatDate } from "@/lib/utils";
import type { CommissionListItem, SlaTier } from "@/lib/queries/commissions";

const STATUS_VARIANT: Record<string, "info" | "warning" | "success" | "outline"> = {
  PENDING: "info",
  APPROVED: "warning",
  PAID: "success",
  VOID: "outline",
};

const SLA_LABEL: Record<SlaTier, string> = {
  ON_TRACK: "On track",
  DUE_SOON: "Due today",
  ESCALATE_MANAGER: "Escalate: Sales Mgr",
  ESCALATE_FINANCE: "Escalate: Finance Dir",
};

const SLA_VARIANT: Record<SlaTier, "success" | "warning" | "destructive"> = {
  ON_TRACK: "success",
  DUE_SOON: "warning",
  ESCALATE_MANAGER: "destructive",
  ESCALATE_FINANCE: "destructive",
};

export function CommissionsTable({ commissions }: { commissions: CommissionListItem[] }) {
  const router = useRouter();
  const [pendingId, setPendingId] = React.useState<string | null>(null);

  async function run(id: string, fn: () => Promise<void>) {
    setPendingId(id);
    await fn();
    router.refresh();
    setPendingId(null);
  }

  return (
    <div className="rounded-lg border border-border">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Unit</TableHead>
            <TableHead>Customer</TableHead>
            <TableHead>Agent</TableHead>
            <TableHead>Amount</TableHead>
            <TableHead>Status</TableHead>
            <TableHead>SLA</TableHead>
            <TableHead>Created</TableHead>
            <TableHead className="text-right">Actions</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {commissions.length === 0 ? (
            <TableRow>
              <TableCell colSpan={8} className="py-10 text-center text-sm text-muted-foreground">
                No commissions yet — closing a deal on the Sales Pipeline creates one automatically.
              </TableCell>
            </TableRow>
          ) : (
            commissions.map((c) => (
              <TableRow key={c.id}>
                <TableCell className="text-sm font-medium">{c.unitNumber}</TableCell>
                <TableCell className="text-sm">{c.customerName}</TableCell>
                <TableCell className="text-sm">
                  {c.agentName} <span className="text-muted-foreground">({c.agentCode})</span>
                </TableCell>
                <TableCell className="text-sm font-semibold tabular-nums">{formatCurrency(c.amount, c.currency)}</TableCell>
                <TableCell>
                  <Badge variant={STATUS_VARIANT[c.status]} dot>
                    {c.status.charAt(0) + c.status.slice(1).toLowerCase()}
                  </Badge>
                </TableCell>
                <TableCell>
                  {c.slaTier ? (
                    <Badge variant={SLA_VARIANT[c.slaTier]}>{SLA_LABEL[c.slaTier]}</Badge>
                  ) : (
                    <span className="text-sm text-muted-foreground">--</span>
                  )}
                </TableCell>
                <TableCell className="text-sm text-muted-foreground">{formatDate(c.createdAt)}</TableCell>
                <TableCell className="text-right">
                  <div className="flex justify-end gap-1.5">
                    {c.status === "PENDING" && (
                      <Button
                        variant="ghost"
                        size="sm"
                        disabled={pendingId === c.id}
                        onClick={() => run(c.id, () => approveCommission(c.id))}
                      >
                        {pendingId === c.id ? <Loader2 className="size-3.5 animate-spin" /> : <CheckCircle2 className="size-3.5" />}
                        Approve
                      </Button>
                    )}
                    {(c.status === "PENDING" || c.status === "APPROVED") && (
                      <Button
                        variant="ghost"
                        size="sm"
                        disabled={pendingId === c.id}
                        onClick={() => run(c.id, () => markCommissionPaid(c.id))}
                      >
                        {pendingId === c.id ? <Loader2 className="size-3.5 animate-spin" /> : <DollarSign className="size-3.5" />}
                        Mark Paid
                      </Button>
                    )}
                    {(c.status === "PENDING" || c.status === "APPROVED") && (
                      <Button
                        variant="ghost"
                        size="sm"
                        className="text-destructive hover:text-destructive"
                        disabled={pendingId === c.id}
                        onClick={() => run(c.id, () => voidCommission(c.id))}
                      >
                        <Ban className="size-3.5" /> Void
                      </Button>
                    )}
                  </div>
                </TableCell>
              </TableRow>
            ))
          )}
        </TableBody>
      </Table>
    </div>
  );
}
