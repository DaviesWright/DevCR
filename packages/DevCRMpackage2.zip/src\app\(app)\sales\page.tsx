import Link from "next/link";
import { Wallet, Scale, Trophy, Coins, Banknote } from "lucide-react";
import { Button } from "@/components/ui/button";
import { KpiCard } from "@/components/dashboard/kpi-card";
import { PipelineBoard } from "@/components/sales/pipeline-board";
import { getPipelineKanban, getPipelineKpis } from "@/lib/queries/sales";
import { getCurrentUser } from "@/lib/queries/reference";
import { formatCurrency } from "@/lib/utils";

export default async function SalesPage() {
  const [opportunities, kpis, currentUser] = await Promise.all([
    getPipelineKanban(),
    getPipelineKpis(),
    getCurrentUser(),
  ]);

  return (
    <div className="flex flex-col gap-6">
      <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-center">
        <div>
          <h1 className="font-heading text-2xl font-semibold">Sales Pipeline</h1>
          <p className="text-sm text-muted-foreground">Drag a card to move it between stages.</p>
        </div>
        <Button variant="outline" asChild>
          <Link href="/sales/commissions">
            <Banknote className="size-4" /> Commissions
          </Link>
        </Button>
      </div>

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <KpiCard title="Pipeline value" value={formatCurrency(kpis.pipelineValue)} icon={Wallet} />
        <KpiCard title="Weighted pipeline" value={formatCurrency(kpis.weightedPipeline)} icon={Scale} />
        <KpiCard title="Win rate" value={`${kpis.winRate.toFixed(1)}%`} icon={Trophy} />
        <KpiCard title="Avg. deal size" value={formatCurrency(kpis.avgDealSize)} icon={Coins} />
      </div>

      <PipelineBoard opportunities={opportunities} currentUserId={currentUser.id} />
    </div>
  );
}
