import type { LucideIcon } from "lucide-react";
import { ArrowDownRight, ArrowUpRight } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { cn } from "@/lib/utils";

export function KpiCard({
  title,
  value,
  changePct,
  changeLabel = "vs. prior 30 days",
  icon: Icon,
}: {
  title: string;
  value: string;
  changePct?: number | null;
  changeLabel?: string;
  icon: LucideIcon;
}) {
  const hasChange = changePct !== undefined && changePct !== null;
  const isUp = hasChange && changePct >= 0;

  return (
    <Card>
      <CardContent className="flex items-start justify-between gap-4 p-5">
        <div>
          <p className="text-sm font-medium text-muted-foreground">{title}</p>
          <p className="mt-1 font-heading text-2xl font-semibold tabular-nums">{value}</p>
          {hasChange && (
            <p
              className={cn(
                "mt-2 flex items-center gap-1 text-xs font-medium",
                isUp ? "text-success" : "text-destructive"
              )}
            >
              {isUp ? <ArrowUpRight className="size-3.5" /> : <ArrowDownRight className="size-3.5" />}
              <span className="sr-only">{isUp ? "Increased" : "Decreased"} by</span>
              {Math.abs(changePct)}%
              <span className="font-normal text-muted-foreground">{changeLabel}</span>
            </p>
          )}
        </div>
        <span className="flex size-9 shrink-0 items-center justify-center rounded-md bg-highlight/15 text-highlight">
          <Icon className="size-5" aria-hidden="true" />
        </span>
      </CardContent>
    </Card>
  );
}
