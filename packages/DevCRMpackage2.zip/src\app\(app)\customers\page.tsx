import { CustomersTable } from "@/components/customers/customers-table";
import { getCustomersList } from "@/lib/queries/customers";

export default async function CustomersPage() {
  const customers = await getCustomersList();

  return (
    <div className="flex flex-col gap-6">
      <div>
        <h1 className="font-heading text-2xl font-semibold">Customers</h1>
        <p className="text-sm text-muted-foreground">{customers.length} customers — unified profile across leads, sales, and support.</p>
      </div>

      <CustomersTable customers={customers} />
    </div>
  );
}
