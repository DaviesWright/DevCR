"use client";

import { useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { Search, UserPlus, Tag, Trash2 } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { LeadStatusBadge, QualificationBadge, SegmentBadge } from "@/components/leads/lead-status-badge";
import { AssignSheet } from "@/components/leads/lead-actions";
import { assignLeadsBulk } from "@/lib/actions/leads";
import { formatCurrency, formatDate, orEmpty } from "@/lib/utils";
import type { LeadListItem } from "@/lib/queries/leads";

const STATUS_FILTERS = [
  "ALL",
  "NEW",
  "CONTACTED",
  "NURTURING",
  "NO_RESPONSE",
  "QUALIFIED",
  "REAL_OPPORTUNITY",
  "UNQUALIFIED",
  "CONVERTED",
] as const;

const STATUS_FILTER_LABEL: Record<(typeof STATUS_FILTERS)[number], string> = {
  ALL: "All statuses",
  NEW: "New",
  CONTACTED: "Contacted",
  NURTURING: "Nurturing",
  NO_RESPONSE: "No response",
  QUALIFIED: "Qualified",
  REAL_OPPORTUNITY: "Real Opportunity",
  UNQUALIFIED: "Unqualified",
  CONVERTED: "Converted",
};

export function LeadsTable({
  leads,
  assignableUsers,
  canBulkAssign = true,
}: {
  leads: LeadListItem[];
  assignableUsers: { id: string; name: string }[];
  canBulkAssign?: boolean;
}) {
  const router = useRouter();
  const [query, setQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState<(typeof STATUS_FILTERS)[number]>("ALL");
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [assignOpen, setAssignOpen] = useState(false);

  const filtered = useMemo(() => {
    return leads.filter((lead) => {
      if (statusFilter !== "ALL" && lead.status !== statusFilter) return false;
      if (!query.trim()) return true;
      const q = query.toLowerCase();
      return lead.name.toLowerCase().includes(q) || lead.email.toLowerCase().includes(q) || lead.source.toLowerCase().includes(q);
    });
  }, [leads, query, statusFilter]);

  const allSelected = filtered.length > 0 && filtered.every((l) => selected.has(l.id));

  function toggleAll() {
    setSelected(allSelected ? new Set() : new Set(filtered.map((l) => l.id)));
  }

  function toggleOne(id: string) {
    setSelected((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  }

  return (
    <div className="flex flex-col gap-3">
      <div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
        <div className="relative max-w-sm flex-1">
          <Search className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Filter by name, email, or source..."
            aria-label="Filter leads"
            className="pl-9"
          />
        </div>
        <Select value={statusFilter} onValueChange={(v) => setStatusFilter(v as typeof statusFilter)}>
          <SelectTrigger className="w-full sm:w-44" aria-label="Filter by status">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            {STATUS_FILTERS.map((s) => (
              <SelectItem key={s} value={s}>
                {STATUS_FILTER_LABEL[s]}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {selected.size > 0 && (
        <div className="flex items-center gap-2 rounded-md border border-border bg-accent px-3 py-2 text-sm">
          <span className="font-medium">{selected.size} selected</span>
          <div className="ml-auto flex gap-1">
            {canBulkAssign && (
              <Button variant="ghost" size="sm" onClick={() => setAssignOpen(true)}>
                <UserPlus className="size-3.5" /> Assign
              </Button>
            )}
            <Button variant="ghost" size="sm">
              <Tag className="size-3.5" /> Update status
            </Button>
            <Button variant="ghost" size="sm" className="text-destructive hover:text-destructive">
              <Trash2 className="size-3.5" /> Delete
            </Button>
          </div>
        </div>
      )}

      <div className="rounded-lg border border-border">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="w-10">
                <Checkbox checked={allSelected} onCheckedChange={toggleAll} aria-label="Select all leads" />
              </TableHead>
              <TableHead>Name</TableHead>
              <TableHead>Segment</TableHead>
              <TableHead>Source</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>Qualification</TableHead>
              <TableHead>BANT Score</TableHead>
              <TableHead>Assigned To</TableHead>
              <TableHead>Budget</TableHead>
              <TableHead>Created</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filtered.length === 0 ? (
              <TableRow>
                <TableCell colSpan={10} className="py-10 text-center text-sm text-muted-foreground">
                  No leads match your filters.
                </TableCell>
              </TableRow>
            ) : (
              filtered.map((lead) => (
                <TableRow key={lead.id} data-state={selected.has(lead.id) ? "selected" : undefined}>
                  <TableCell>
                    <Checkbox
                      checked={selected.has(lead.id)}
                      onCheckedChange={() => toggleOne(lead.id)}
                      aria-label={`Select ${lead.name}`}
                    />
                  </TableCell>
                  <TableCell>
                    <Link href={`/leads/${lead.id}`} className="font-medium text-foreground hover:underline">
                      {lead.name}
                    </Link>
                    <p className="text-xs text-muted-foreground">{lead.email}</p>
                  </TableCell>
                  <TableCell>{lead.segment ? <SegmentBadge segment={lead.segment} /> : <span className="text-sm text-muted-foreground">--</span>}</TableCell>
                  <TableCell className="text-sm">{lead.source}</TableCell>
                  <TableCell>
                    <LeadStatusBadge status={lead.status as never} />
                  </TableCell>
                  <TableCell>
                    <QualificationBadge status={lead.qualificationStatus as never} />
                  </TableCell>
                  <TableCell className="tabular-nums">{lead.bantScore}</TableCell>
                  <TableCell className="text-sm">{orEmpty(lead.assignedTo)}</TableCell>
                  <TableCell className="text-sm tabular-nums">
                    {lead.budgetMin || lead.budgetMax
                      ? `${lead.budgetMin ? formatCurrency(lead.budgetMin, lead.currency) : "--"} – ${lead.budgetMax ? formatCurrency(lead.budgetMax, lead.currency) : "--"}`
                      : "--"}
                  </TableCell>
                  <TableCell className="text-sm text-muted-foreground">{formatDate(lead.createdAt)}</TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>

      <AssignSheet
        open={assignOpen}
        onOpenChange={setAssignOpen}
        assignableUsers={assignableUsers}
        run={async (fn, onDone) => {
          await fn();
          router.refresh();
          setSelected(new Set());
          onDone?.();
        }}
        onAssign={(userId) => assignLeadsBulk(Array.from(selected), userId)}
      />
    </div>
  );
}
