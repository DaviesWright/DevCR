"use client";

import { useMemo, useState } from "react";
import Link from "next/link";
import { Search } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { orEmpty } from "@/lib/utils";
import type { CustomerListItem } from "@/lib/queries/customers";

const SEGMENT_LABEL: Record<string, string> = {
  LOCAL_RESIDENTIAL: "Local Residential",
  DIASPORA: "Diaspora",
  CORPORATE: "Corporate",
  INVESTOR: "Investor",
};

const KYC_VARIANT: Record<string, "success" | "warning" | "destructive"> = {
  VERIFIED: "success",
  PENDING: "warning",
  REJECTED: "destructive",
};

export function CustomersTable({ customers }: { customers: CustomerListItem[] }) {
  const [query, setQuery] = useState("");

  const filtered = useMemo(() => {
    if (!query.trim()) return customers;
    const q = query.toLowerCase();
    return customers.filter(
      (c) => c.name.toLowerCase().includes(q) || c.phone.includes(q) || (c.email ?? "").toLowerCase().includes(q)
    );
  }, [customers, query]);

  return (
    <div className="flex flex-col gap-3">
      <div className="relative max-w-sm">
        <Search className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
        <Input
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Filter by name, phone, or email..."
          aria-label="Filter customers"
          className="pl-9"
        />
      </div>

      <div className="rounded-lg border border-border">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Name</TableHead>
              <TableHead>Phone</TableHead>
              <TableHead>Segment</TableHead>
              <TableHead>KYC</TableHead>
              <TableHead>Leads</TableHead>
              <TableHead>Sales</TableHead>
              <TableHead>Complaints</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filtered.length === 0 ? (
              <TableRow>
                <TableCell colSpan={7} className="py-10 text-center text-sm text-muted-foreground">
                  No customers match your filter.
                </TableCell>
              </TableRow>
            ) : (
              filtered.map((c) => (
                <TableRow key={c.id}>
                  <TableCell>
                    <Link href={`/customers/${c.id}`} className="font-medium text-foreground hover:underline">
                      {c.name}
                    </Link>
                    <p className="text-xs text-muted-foreground">{orEmpty(c.email)}</p>
                  </TableCell>
                  <TableCell className="text-sm">{c.phone}</TableCell>
                  <TableCell className="text-sm">{c.segment ? SEGMENT_LABEL[c.segment] ?? c.segment : "--"}</TableCell>
                  <TableCell>
                    <Badge variant={KYC_VARIANT[c.kycStatus] ?? "outline"}>{c.kycStatus.toLowerCase()}</Badge>
                  </TableCell>
                  <TableCell className="text-sm tabular-nums">{c.leadCount}</TableCell>
                  <TableCell className="text-sm tabular-nums">{c.saleCount}</TableCell>
                  <TableCell className="text-sm tabular-nums">{c.complaintCount}</TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}
