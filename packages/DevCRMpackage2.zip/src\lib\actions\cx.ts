"use server";

import { revalidatePath } from "next/cache";
import { prisma } from "@/lib/prisma";

function revalidateCx(complaintId?: string) {
  revalidatePath("/cx");
  if (complaintId) revalidatePath(`/cx/complaints/${complaintId}`);
}

export async function createComplaint(input: {
  customerId: string;
  unitId?: string;
  categoryId: string;
  subject: string;
  description: string;
  priority?: string;
  assignedToId?: string;
}): Promise<{ complaintId: string }> {
  const category = await prisma.complaintCategory.findUniqueOrThrow({ where: { id: input.categoryId } });
  const now = new Date();
  const complaint = await prisma.complaint.create({
    data: {
      customerId: input.customerId,
      unitId: input.unitId || undefined,
      categoryId: input.categoryId,
      subject: input.subject,
      description: input.description,
      priority: (input.priority as never) || category.defaultPriority,
      assignedToId: input.assignedToId || undefined,
      status: input.assignedToId ? "ASSIGNED" : "OPEN",
      sla: {
        create: {
          responseDueAt: new Date(now.getTime() + category.responseSlaHours * 3600000),
          resolutionDueAt: new Date(now.getTime() + category.resolutionSlaHours * 3600000),
        },
      },
    },
  });
  revalidateCx(complaint.id);
  return { complaintId: complaint.id };
}

export async function assignComplaint(complaintId: string, userId: string) {
  const complaint = await prisma.complaint.findUniqueOrThrow({ where: { id: complaintId }, select: { status: true } });
  await prisma.complaint.update({
    where: { id: complaintId },
    data: {
      assignedToId: userId,
      status: complaint.status === "OPEN" ? "ASSIGNED" : undefined,
    },
  });
  revalidateCx(complaintId);
}

export async function addComplaintUpdate(complaintId: string, input: { note: string; updatedById: string }) {
  await prisma.$transaction(async (tx) => {
    await tx.complaintUpdate.create({
      data: { complaintId, note: input.note, updatedById: input.updatedById },
    });
    const complaint = await tx.complaint.findUniqueOrThrow({ where: { id: complaintId }, select: { status: true } });
    if (complaint.status === "OPEN" || complaint.status === "ASSIGNED") {
      await tx.complaint.update({ where: { id: complaintId }, data: { status: "IN_PROGRESS" } });
    }
    await tx.complaintSLA.updateMany({
      where: { complaintId, respondedAt: null },
      data: { respondedAt: new Date() },
    });
  });
  revalidateCx(complaintId);
}

export async function resolveComplaint(complaintId: string, input: { note?: string; userId: string }) {
  const now = new Date();
  await prisma.$transaction(async (tx) => {
    await tx.complaint.update({ where: { id: complaintId }, data: { status: "RESOLVED", resolvedAt: now } });
    await tx.complaintSLA.updateMany({ where: { complaintId }, data: { resolvedAt: now } });
    if (input.note) {
      await tx.complaintUpdate.create({ data: { complaintId, note: input.note, updatedById: input.userId } });
    }
  });
  revalidateCx(complaintId);
}

export async function closeComplaint(complaintId: string) {
  await prisma.complaint.update({ where: { id: complaintId }, data: { status: "CLOSED", closedAt: new Date() } });
  revalidateCx(complaintId);
}

export async function reopenComplaint(complaintId: string, input: { reason: string; userId: string }) {
  await prisma.$transaction(async (tx) => {
    await tx.complaint.update({
      where: { id: complaintId },
      data: { status: "REOPENED", resolvedAt: null, closedAt: null },
    });
    await tx.complaintUpdate.create({
      data: { complaintId, note: `Reopened: ${input.reason}`, updatedById: input.userId },
    });
  });
  revalidateCx(complaintId);
}

export async function escalateComplaint(
  complaintId: string,
  input: { reason: string; fromUserId: string; toUserId: string }
) {
  await prisma.escalation.create({
    data: { complaintId, reason: input.reason, escalatedFromId: input.fromUserId, escalatedToId: input.toUserId },
  });
  revalidateCx(complaintId);
}

export async function resolveEscalation(escalationId: string, complaintId: string) {
  await prisma.escalation.update({
    where: { id: escalationId },
    data: { status: "RESOLVED", resolvedAt: new Date() },
  });
  revalidateCx(complaintId);
}

export async function scheduleHandover(input: { customerId: string; unitId: string; scheduledAt: string }) {
  await prisma.handover.create({
    data: {
      customerId: input.customerId,
      unitId: input.unitId,
      scheduledAt: new Date(input.scheduledAt),
      status: "SCHEDULED",
    },
  });
  revalidatePath("/cx");
}

export async function completeHandover(handoverId: string, conductedById: string) {
  await prisma.handover.update({
    where: { id: handoverId },
    data: { status: "COMPLETED", completedAt: new Date(), conductedById },
  });
  revalidatePath("/cx");
}

export async function cancelHandover(handoverId: string) {
  await prisma.handover.update({ where: { id: handoverId }, data: { status: "CANCELLED" } });
  revalidatePath("/cx");
}
