import Link from "next/link";
import { Plus, BarChart3 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { LeadsTable } from "@/components/leads/leads-table";
import { getLeadsList } from "@/lib/queries/leads";
import { getAssignableUsers, getCurrentUser } from "@/lib/queries/reference";

export default async function LeadsPage() {
  const [leads, assignableUsers, currentUser] = await Promise.all([
    getLeadsList(),
    getAssignableUsers(),
    getCurrentUser(),
  ]);

  return (
    <div className="flex flex-col gap-6">
      <div className="flex items-start justify-between gap-4">
        <div>
          <h1 className="font-heading text-2xl font-semibold">Leads</h1>
          <p className="text-sm text-muted-foreground">{leads.length} leads</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" asChild>
            <Link href="/leads/analytics">
              <BarChart3 className="size-4" /> Analytics
            </Link>
          </Button>
          <Button asChild>
            <Link href="/leads/new">
              <Plus className="size-4" /> New Lead
            </Link>
          </Button>
        </div>
      </div>

      <LeadsTable leads={leads} assignableUsers={assignableUsers} canBulkAssign={currentUser.isManager} />
    </div>
  );
}
