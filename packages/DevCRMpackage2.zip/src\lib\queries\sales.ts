import { prisma } from "@/lib/prisma";

export const PIPELINE_STAGES = [
  "PROSPECTING",
  "QUALIFIED",
  "SITE_VISIT",
  "RESERVATION",
  "NEGOTIATION",
  "CONTRACT",
  "CLOSED_WON",
  "CLOSED_LOST",
] as const;

export const STAGE_LABEL: Record<string, string> = {
  PROSPECTING: "Prospecting",
  QUALIFIED: "Qualified",
  SITE_VISIT: "Site Visit",
  RESERVATION: "Reservation",
  NEGOTIATION: "Negotiation",
  CONTRACT: "Contract",
  CLOSED_WON: "Closed Won",
  CLOSED_LOST: "Closed Lost",
};

export async function getPipelineKanban() {
  const opportunities = await prisma.opportunity.findMany({
    where: { deletedAt: null },
    include: {
      customer: { select: { firstName: true, lastName: true } },
      unit: { select: { unitNumber: true } },
      owner: { select: { firstName: true, lastName: true } },
      reservations: { select: { id: true }, take: 1 },
    },
    orderBy: { updatedAt: "desc" },
  });

  return opportunities.map((o) => ({
    id: o.id,
    stage: o.stage,
    customerId: o.customerId,
    unitId: o.unitId,
    customerName: `${o.customer.firstName} ${o.customer.lastName}`,
    unitNumber: o.unit?.unitNumber ?? null,
    expectedValue: Number(o.expectedValue),
    currency: o.currency,
    probability: o.probability,
    ownerName: `${o.owner.firstName} ${o.owner.lastName}`,
    updatedAt: o.updatedAt,
    hasReservation: o.reservations.length > 0,
  }));
}

export type PipelineCard = Awaited<ReturnType<typeof getPipelineKanban>>[number];

export async function getPipelineKpis() {
  const opportunities = await prisma.opportunity.findMany({
    where: { deletedAt: null },
    select: { stage: true, expectedValue: true, probability: true },
  });

  const open = opportunities.filter((o) => o.stage !== "CLOSED_WON" && o.stage !== "CLOSED_LOST");
  const won = opportunities.filter((o) => o.stage === "CLOSED_WON");
  const lost = opportunities.filter((o) => o.stage === "CLOSED_LOST");
  const closed = won.length + lost.length;

  const pipelineValue = open.reduce((sum, o) => sum + Number(o.expectedValue), 0);
  const weightedPipeline = open.reduce((sum, o) => sum + (Number(o.expectedValue) * o.probability) / 100, 0);
  const winRate = closed ? (won.length / closed) * 100 : 0;
  const avgDealSize = open.length ? pipelineValue / open.length : 0;

  return { pipelineValue, weightedPipeline, winRate, avgDealSize, openCount: open.length };
}
