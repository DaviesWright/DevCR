import type { LucideIcon } from "lucide-react";
import {
  LayoutDashboard,
  Users,
  UserSquare2,
  Building2,
  TrendingUp,
  Wallet,
  HardHat,
  HeartHandshake,
  Wrench,
  BarChart3,
  Settings,
  Megaphone,
} from "lucide-react";

export type NavItem = {
  label: string;
  href: string;
  icon: LucideIcon;
  /** Modules not yet built get a disabled, roadmap-labeled entry instead of a dead link. */
  comingSoon?: boolean;
};

export const NAV_ITEMS: NavItem[] = [
  { label: "Dashboard", href: "/", icon: LayoutDashboard },
  { label: "Leads", href: "/leads", icon: Users },
  { label: "Customers", href: "/customers", icon: UserSquare2 },
  { label: "Projects", href: "/projects", icon: Building2, comingSoon: true },
  { label: "Sales", href: "/sales", icon: TrendingUp },
  { label: "Finance", href: "/finance", icon: Wallet, comingSoon: true },
  { label: "Construction", href: "/construction", icon: HardHat, comingSoon: true },
  { label: "Customer Experience", href: "/cx", icon: HeartHandshake },
  { label: "Marketing", href: "/marketing", icon: Megaphone, comingSoon: true },
  { label: "Facilities", href: "/facilities", icon: Wrench, comingSoon: true },
  { label: "Reports", href: "/reports", icon: BarChart3, comingSoon: true },
  { label: "Admin", href: "/admin", icon: Settings, comingSoon: true },
];

export type QuickAction = { label: string; href: string };

export const QUICK_ACTIONS: QuickAction[] = [
  { label: "New Lead", href: "/leads/new" },
  { label: "Log Call", href: "/leads?action=log-call" },
  { label: "Add Task", href: "/leads?action=add-task" },
];
