import { PrismaClient } from "@prisma/client";
import { CX_PLAYBOOK_TEMPLATES } from "./data/cx-playbook-templates";
import { CX_DEPARTMENT_INTERACTIONS } from "./data/cx-department-interactions";

const prisma = new PrismaClient();

async function main() {
  console.log("Seeding...");

  const salesRole = await prisma.role.create({ data: { name: "Sales Agent", isSystem: true } });
  const managerRole = await prisma.role.create({ data: { name: "Sales Manager", isSystem: true } });
  const salesDept = await prisma.department.create({ data: { name: "Sales" } });

  const jane = await prisma.user.create({
    data: {
      firstName: "Jane",
      lastName: "Agent",
      email: "jane.agent@devtraco.com",
      passwordHash: "seed-only-not-a-real-hash",
      roleId: salesRole.id,
      departmentId: salesDept.id,
    },
  });
  const michael = await prisma.user.create({
    data: {
      firstName: "Michael",
      lastName: "Osei",
      email: "michael.osei@devtraco.com",
      passwordHash: "seed-only-not-a-real-hash",
      roleId: managerRole.id,
      departmentId: salesDept.id,
    },
  });

  const janeAgent = await prisma.salesAgent.create({
    data: { userId: jane.id, agentCode: "AG-001", commissionRate: 3 },
  });
  await prisma.salesAgent.create({
    data: { userId: michael.id, agentCode: "AG-002", commissionRate: 2.5 },
  });

  // Exact tag taxonomy from Devtraco_Sales_Playbook_v1.0.docx §1.3/§1.4 — this is
  // the primary data point for measuring marketing ROI and channel performance,
  // so the tags must match what Sales actually selects, not a paraphrase.
  const websiteSource = await prisma.leadSource.create({ data: { name: "Website" } });
  const referralSource = await prisma.leadSource.create({ data: { name: "Referral" } });
  await prisma.leadSource.create({ data: { name: "Social Media - Facebook" } });
  await prisma.leadSource.create({ data: { name: "Social Media - Instagram" } });
  await prisma.leadSource.create({ data: { name: "Walk-in" } });
  await prisma.leadSource.create({ data: { name: "Event / Exhibition" } });
  await prisma.leadSource.create({ data: { name: "Google Ads" } });
  await prisma.leadSource.create({ data: { name: "Agent / Broker" } });
  await prisma.leadSource.create({ data: { name: "Direct Enquiry" } });

  const propType3bed = await prisma.propertyType.create({
    data: { name: "3-Bedroom Townhouse", bedrooms: 3, bathrooms: 3, builtAreaSqm: 165 },
  });
  const propType4bed = await prisma.propertyType.create({
    data: { name: "4-Bedroom Detached", bedrooms: 4, bathrooms: 4, builtAreaSqm: 220 },
  });

  const development = await prisma.development.create({
    data: {
      name: "Airport Hills Residences",
      projectCode: "AHR-001",
      location: "Accra, Ghana",
      region: "Greater Accra",
      status: "SELLING",
      totalUnits: 240,
    },
  });

  const block = await prisma.block.create({ data: { developmentId: development.id, name: "Block A" } });
  const floor = await prisma.floor.create({ data: { blockId: block.id, level: 3 } });

  const unitAvailable = await prisma.unit.create({
    data: {
      developmentId: development.id,
      blockId: block.id,
      floorId: floor.id,
      propertyTypeId: propType3bed.id,
      unitNumber: "A-301",
      currentPrice: 850000,
      status: "AVAILABLE",
    },
  });
  const unitReserved = await prisma.unit.create({
    data: {
      developmentId: development.id,
      blockId: block.id,
      floorId: floor.id,
      propertyTypeId: propType4bed.id,
      unitNumber: "A-302",
      currentPrice: 1200000,
      status: "RESERVED",
    },
  });
  const unitSold = await prisma.unit.create({
    data: {
      developmentId: development.id,
      blockId: block.id,
      floorId: floor.id,
      propertyTypeId: propType3bed.id,
      unitNumber: "A-203",
      currentPrice: 850000,
      status: "SOLD",
    },
  });
  await prisma.unit.createMany({
    data: Array.from({ length: 5 }, (_, i) => ({
      developmentId: development.id,
      blockId: block.id,
      floorId: floor.id,
      propertyTypeId: propType3bed.id,
      unitNumber: `A-40${i + 1}`,
      currentPrice: 875000,
      status: "AVAILABLE" as const,
    })),
  });

  const customerKwame = await prisma.customer.create({
    data: {
      firstName: "Kwame",
      lastName: "Mensah",
      email: "kwame.mensah@example.com",
      phone: "+233241234567",
      nationality: "Ghanaian",
      segment: "LOCAL_RESIDENTIAL",
      kycStatus: "VERIFIED",
      assignedSalesRepId: jane.id,
    },
  });
  const customerAma = await prisma.customer.create({
    data: {
      firstName: "Ama",
      lastName: "Owusu",
      email: "ama.owusu@example.com",
      phone: "+233201234568",
      nationality: "Ghanaian",
      segment: "INVESTOR",
      kycStatus: "PENDING",
      assignedSalesRepId: jane.id,
    },
  });
  const customerJohn = await prisma.customer.create({
    data: {
      firstName: "John",
      lastName: "Doe",
      email: "john.doe@example.com",
      phone: "+233551234569",
      nationality: "British",
      segment: "DIASPORA",
      kycStatus: "PENDING",
      assignedSalesRepId: michael.id,
    },
  });

  const leadJohn = await prisma.lead.create({
    data: {
      customerId: customerJohn.id,
      sourceId: websiteSource.id,
      assignedToId: jane.id,
      budgetMin: 700000,
      budgetMax: 900000,
      preferredLocation: "Airport Hills",
      propertyTypeId: propType3bed.id,
      score: 85,
      status: "QUALIFIED",
      bantScore: 78,
      qualificationStatus: "QUALIFIED",
      qualifiedAt: new Date(),
      notes: "Interested in a 3-bedroom unit, cash buyer, diaspora client visiting next month.",
      createdAt: new Date(Date.now() - 4 * 86400000),
    },
  });
  const leadAma = await prisma.lead.create({
    data: {
      customerId: customerAma.id,
      sourceId: referralSource.id,
      assignedToId: jane.id,
      budgetMin: 1000000,
      budgetMax: 1300000,
      preferredLocation: "Airport Hills",
      propertyTypeId: propType4bed.id,
      score: 45,
      status: "CONTACTED",
      bantScore: 42,
      qualificationStatus: "REVIEW",
      notes: null,
      createdAt: new Date(Date.now() - 1 * 86400000 - 6 * 3600000),
    },
  });
  await prisma.lead.create({
    data: {
      customerId: customerKwame.id,
      sourceId: websiteSource.id,
      score: 20,
      status: "NEW",
      bantScore: 15,
      qualificationStatus: "UNQUALIFIED",
    },
  });

  await prisma.leadActivity.createMany({
    data: [
      { leadId: leadJohn.id, type: "SITE_VISIT", description: "Toured Block A show unit", createdById: jane.id, occurredAt: new Date(Date.now() - 2 * 86400000) },
      { leadId: leadJohn.id, type: "CALL", description: "Discussed payment plan options", createdById: jane.id, occurredAt: new Date(Date.now() - 1 * 86400000) },
      { leadId: leadAma.id, type: "EMAIL", description: "Sent brochure and pricing sheet", createdById: jane.id, occurredAt: new Date(Date.now() - 3 * 3600000) },
    ],
  });

  await prisma.bantScore.create({
    data: {
      leadId: leadJohn.id,
      userId: jane.id,
      budgetScore: 90,
      authorityScore: 80,
      needScore: 75,
      timelineScore: 65,
      fitScore: 82,
      totalScore: 78,
      status: "QUALIFIED",
      notes: "Confirmed budget with proof of funds.",
    },
  });
  await prisma.behavioralScore.create({
    data: {
      leadId: leadJohn.id,
      emailOpens: 6,
      emailClicks: 3,
      siteVisits: 2,
      documentViews: 4,
      meetingsAttended: 1,
      callsCompleted: 2,
      totalScore: 71,
      engagementLevel: "HIGH",
      lastActivityAt: new Date(Date.now() - 1 * 86400000),
    },
  });
  await prisma.behavioralScore.create({
    data: {
      leadId: leadAma.id,
      emailOpens: 1,
      siteVisits: 0,
      totalScore: 18,
      engagementLevel: "LOW",
    },
  });

  await prisma.opportunity.create({
    data: {
      leadId: leadJohn.id,
      customerId: customerJohn.id,
      unitId: unitAvailable.id,
      expectedValue: 850000,
      stage: "NEGOTIATION",
      probability: 70,
      ownerId: jane.id,
    },
  });
  await prisma.opportunity.create({
    data: {
      leadId: leadAma.id,
      customerId: customerAma.id,
      unitId: unitReserved.id,
      expectedValue: 1200000,
      stage: "RESERVATION",
      probability: 50,
      ownerId: jane.id,
    },
  });
  await prisma.opportunity.create({
    data: {
      customerId: customerKwame.id,
      expectedValue: 650000,
      stage: "PROSPECTING",
      probability: 20,
      ownerId: michael.id,
    },
  });

  // Reservation expiring soon — feeds the header/dashboard alerts.
  await prisma.reservation.create({
    data: {
      unitId: unitReserved.id,
      customerId: customerAma.id,
      reservationFee: 20000,
      expiryDate: new Date(Date.now() + 3 * 86400000),
      status: "ACTIVE",
    },
  });

  const sale = await prisma.sale.create({
    data: {
      unitId: unitSold.id,
      customerId: customerKwame.id,
      salePrice: 850000,
      status: "ACTIVE",
    },
  });
  await prisma.commission.create({
    data: {
      saleId: sale.id,
      agentId: janeAgent.id,
      amount: 25500,
      status: "PENDING",
      // Backdated past the Sales Workflow Optimisation doc's Day-8 Finance
      // Director escalation threshold — exercises the SLA-risk badge with real seed data.
      createdAt: new Date(Date.now() - 9 * 86400000),
    },
  });
  await prisma.clientHandover.create({
    data: {
      saleId: sale.id,
      customerId: customerKwame.id,
      consultantId: jane.id,
      // Backdated past the Sales Playbook's 24h CX-acknowledgement SLA —
      // exercises the "Ack overdue" badge with real seed data.
      notifiedAt: new Date(Date.now() - 30 * 3600000),
    },
  });

  const paymentPlan = await prisma.paymentPlan.create({
    data: {
      saleId: sale.id,
      totalAmount: 850000,
      downPayment: 170000,
      status: "ACTIVE",
    },
  });
  await prisma.paymentSchedule.create({
    data: {
      paymentPlanId: paymentPlan.id,
      installmentNo: 1,
      dueDate: new Date(Date.now() - 5 * 86400000),
      amountDue: 113333,
      status: "OVERDUE",
    },
  });
  await prisma.paymentSchedule.create({
    data: {
      paymentPlanId: paymentPlan.id,
      installmentNo: 2,
      dueDate: new Date(Date.now() + 25 * 86400000),
      amountDue: 113333,
      status: "PENDING",
    },
  });

  const plumbingCategory = await prisma.complaintCategory.create({
    data: { name: "Plumbing", defaultPriority: "HIGH", responseSlaHours: 4, resolutionSlaHours: 24 },
  });
  const billingCategory = await prisma.complaintCategory.create({
    data: { name: "Billing", defaultPriority: "MEDIUM", responseSlaHours: 24, resolutionSlaHours: 72 },
  });

  const plumbingComplaint = await prisma.complaint.create({
    data: {
      customerId: customerKwame.id,
      unitId: unitSold.id,
      categoryId: plumbingCategory.id,
      subject: "Leaking kitchen tap",
      description: "Tap has been leaking since move-in.",
      priority: "HIGH",
      status: "IN_PROGRESS",
      assignedToId: michael.id,
      openedAt: new Date(Date.now() - 3 * 86400000),
    },
  });
  await prisma.complaintSLA.create({
    data: {
      complaintId: plumbingComplaint.id,
      // Overdue on purpose — exercises the SLA-breach KPI and badge with real seed data.
      responseDueAt: new Date(Date.now() - 3 * 86400000 + 4 * 3600000),
      resolutionDueAt: new Date(Date.now() - 2 * 86400000),
      respondedAt: new Date(Date.now() - 3 * 86400000 + 3 * 3600000),
    },
  });
  await prisma.complaintUpdate.create({
    data: {
      complaintId: plumbingComplaint.id,
      note: "Plumber dispatched, awaiting parts for the mixer valve.",
      updatedById: michael.id,
    },
  });
  await prisma.escalation.create({
    data: {
      complaintId: plumbingComplaint.id,
      reason: "Resolution SLA breached — parts delay from supplier.",
      escalatedFromId: michael.id,
      escalatedToId: jane.id,
    },
  });

  const billingComplaint = await prisma.complaint.create({
    data: {
      customerId: customerKwame.id,
      unitId: unitSold.id,
      categoryId: billingCategory.id,
      subject: "Service charge query",
      description: "Question about Q1 service charge breakdown.",
      priority: "LOW",
      status: "OPEN",
    },
  });
  await prisma.complaintSLA.create({
    data: {
      complaintId: billingComplaint.id,
      responseDueAt: new Date(Date.now() + 22 * 3600000),
      resolutionDueAt: new Date(Date.now() + 68 * 3600000),
    },
  });

  await prisma.handover.create({
    data: {
      unitId: unitSold.id,
      customerId: customerKwame.id,
      status: "COMPLETED",
      scheduledAt: new Date(Date.now() - 30 * 86400000),
      completedAt: new Date(Date.now() - 29 * 86400000),
      conductedById: jane.id,
    },
  });

  // CX Workflow: State 2 Operational Playbook — 11 templates, each with its own grouped
  // Process Execution + Quality & Control steps, transcribed verbatim in cx-playbook-templates.ts.
  for (const tpl of CX_PLAYBOOK_TEMPLATES) {
    const template = await prisma.checklistTemplate.create({
      data: {
        stageNumber: tpl.stageNumber,
        title: tpl.title,
        goal: tpl.goal,
        trigger: tpl.trigger,
        owner: tpl.owner,
        sla: tpl.sla,
        isOpenDesignItem: tpl.isOpenDesignItem ?? false,
      },
    });
    let order = 0;
    for (const group of tpl.steps) {
      for (const item of group.items) {
        order += 1;
        await prisma.checklistStep.create({
          data: {
            templateId: template.id,
            groupLabel: group.groupLabel,
            order,
            kind: item.kind,
            label: item.label,
            notificationRecipient: item.notificationRecipient,
            notificationAction: item.notificationAction,
            crossDepartmental: group.crossDepartmental,
          },
        });
      }
    }
  }

  for (const dept of CX_DEPARTMENT_INTERACTIONS) {
    let order = 0;
    for (const row of dept.rows) {
      order += 1;
      await prisma.departmentInteraction.create({
        data: {
          department: dept.department,
          keyContact: dept.keyContact,
          interactionType: row.interactionType,
          frequency: row.frequency,
          keyActivities: row.keyActivities,
          order,
        },
      });
    }
  }

  const templates = await prisma.checklistTemplate.findMany();
  const templateByStage = new Map(templates.map((t) => [t.stageNumber, t]));

  // Demo run: Stage 08 (Complaints) in progress against the seeded plumbing complaint —
  // some steps ticked, some quality checks still open, to exercise the progress/flag UI.
  const complaintsTemplate = templateByStage.get(8)!;
  const complaintsSteps = await prisma.checklistStep.findMany({ where: { templateId: complaintsTemplate.id }, orderBy: { order: "asc" } });
  const complaintsRun = await prisma.checklistRun.create({
    data: {
      templateId: complaintsTemplate.id,
      customerId: customerKwame.id,
      relatedEntityType: "COMPLAINT",
      relatedEntityId: plumbingComplaint.id,
      startedById: michael.id,
      startedAt: new Date(Date.now() - 2 * 86400000),
    },
  });
  for (const step of complaintsSteps.slice(0, 3)) {
    await prisma.checklistStepCompletion.create({
      data: { runId: complaintsRun.id, stepId: step.id, completed: true, completedAt: new Date(), completedById: michael.id },
    });
  }

  // Demo run: Stage 04 (Handover) fully completed against the seeded (already-completed)
  // property handover.
  const handoverTemplate = templateByStage.get(4)!;
  const handoverSteps = await prisma.checklistStep.findMany({ where: { templateId: handoverTemplate.id }, orderBy: { order: "asc" } });
  const handoverRun = await prisma.checklistRun.create({
    data: {
      templateId: handoverTemplate.id,
      customerId: customerKwame.id,
      relatedEntityType: "HANDOVER",
      startedById: jane.id,
      startedAt: new Date(Date.now() - 30 * 86400000),
      completedAt: new Date(Date.now() - 29 * 86400000),
    },
  });
  for (const step of handoverSteps) {
    await prisma.checklistStepCompletion.create({
      data: { runId: handoverRun.id, stepId: step.id, completed: true, completedAt: new Date(Date.now() - 29 * 86400000), completedById: jane.id },
    });
  }

  console.log("Seed complete.");
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
