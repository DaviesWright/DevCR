import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { EmailIntegrations } from "@/components/admin/email-integrations";
import { getEmailConnectionsForUser } from "@/lib/actions/integrations";
import { getCurrentUser } from "@/lib/queries/reference";
import { isGoogleConfigured, isMicrosoftConfigured } from "@/lib/integrations/config";

export default async function AdminPage() {
  const currentUser = await getCurrentUser();
  const connections = await getEmailConnectionsForUser(currentUser.id);

  return (
    <div className="flex flex-col gap-6">
      <div>
        <h1 className="font-heading text-2xl font-semibold">Admin</h1>
        <p className="text-sm text-muted-foreground">Workspace and integration settings.</p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Email &amp; calendar sync</CardTitle>
        </CardHeader>
        <CardContent className="flex flex-col gap-3">
          <p className="text-sm text-muted-foreground">
            Connect your own Gmail or Outlook account to pull your real sent/received emails and calendar events into
            each customer's timeline — no more re-typing what you already sent. Sync is on-demand ("Sync now") since
            this app has no public URL for a real-time push subscription.
          </p>
          <EmailIntegrations
            connections={connections}
            googleConfigured={isGoogleConfigured()}
            microsoftConfigured={isMicrosoftConfigured()}
          />
        </CardContent>
      </Card>
    </div>
  );
}
