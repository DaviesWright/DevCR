import { prisma } from "@/lib/prisma";

export async function getLeadsList() {
  const leads = await prisma.lead.findMany({
    where: { deletedAt: null },
    orderBy: { createdAt: "desc" },
    include: {
      customer: { select: { firstName: true, lastName: true, email: true, segment: true } },
      source: { select: { name: true } },
      assignedTo: { select: { firstName: true, lastName: true } },
    },
    take: 100,
  });

  return leads.map((lead) => ({
    id: lead.id,
    name: `${lead.customer.firstName} ${lead.customer.lastName}`,
    email: lead.customer.email ?? "",
    segment: lead.customer.segment,
    source: lead.source.name,
    status: lead.status,
    qualificationStatus: lead.qualificationStatus,
    bantScore: lead.bantScore,
    assignedTo: lead.assignedTo ? `${lead.assignedTo.firstName} ${lead.assignedTo.lastName}` : null,
    budgetMin: lead.budgetMin ? Number(lead.budgetMin) : null,
    budgetMax: lead.budgetMax ? Number(lead.budgetMax) : null,
    currency: lead.currency,
    createdAt: lead.createdAt,
  }));
}

export type LeadListItem = Awaited<ReturnType<typeof getLeadsList>>[number];

export async function getLeadDetail(id: string) {
  const lead = await prisma.lead.findUnique({
    where: { id },
    include: {
      customer: true,
      source: true,
      campaign: true,
      referredBy: { select: { id: true, firstName: true, lastName: true } },
      assignedTo: { select: { firstName: true, lastName: true, email: true } },
      propertyType: true,
      activities: {
        orderBy: { occurredAt: "desc" },
        include: { createdBy: { select: { firstName: true, lastName: true } } },
      },
      opportunities: {
        include: { unit: { select: { unitNumber: true } } },
        orderBy: { createdAt: "desc" },
      },
      siteVisits: { orderBy: { scheduledAt: "desc" } },
      bantScores: { orderBy: { createdAt: "desc" }, take: 1 },
      behavioralScores: { orderBy: { scoreDate: "desc" }, take: 1 },
    },
  });

  if (!lead) return null;

  const tasks = await prisma.task.findMany({
    where: { relatedEntityType: "LEAD", relatedEntityId: id },
    orderBy: { createdAt: "desc" },
    include: { assignedTo: { select: { firstName: true, lastName: true } } },
  });

  const latestBant = lead.bantScores[0] ?? null;
  const latestBehavioral = lead.behavioralScores[0] ?? null;

  return {
    id: lead.id,
    status: lead.status,
    qualificationStatus: lead.qualificationStatus,
    bantScore: lead.bantScore,
    realOpportunityAt: lead.realOpportunityAt,
    suspectedPersona: lead.suspectedPersona,
    suspectedPersonaNote: lead.suspectedPersonaNote,
    notes: lead.notes,
    lostReason: lead.lostReason,
    lostReasonNote: lead.lostReasonNote,
    assignedToId: lead.assignedToId,
    preferredLocation: lead.preferredLocation,
    propertyType: lead.propertyType?.name ?? null,
    budgetMin: lead.budgetMin ? Number(lead.budgetMin) : null,
    budgetMax: lead.budgetMax ? Number(lead.budgetMax) : null,
    currency: lead.currency,
    createdAt: lead.createdAt,
    customer: {
      id: lead.customer.id,
      firstName: lead.customer.firstName,
      lastName: lead.customer.lastName,
      email: lead.customer.email,
      phone: lead.customer.phone,
      segment: lead.customer.segment,
    },
    source: lead.source.name,
    campaign: lead.campaign?.name ?? null,
    referredBy: lead.referredBy ? { id: lead.referredBy.id, name: `${lead.referredBy.firstName} ${lead.referredBy.lastName}` } : null,
    referralRewardStatus: lead.referralRewardStatus,
    assignedTo: lead.assignedTo ? `${lead.assignedTo.firstName} ${lead.assignedTo.lastName}` : null,
    bantBreakdown: latestBant
      ? {
          budget: latestBant.budgetScore,
          authority: latestBant.authorityScore,
          need: latestBant.needScore,
          timeline: latestBant.timelineScore,
          fit: latestBant.fitScore,
          total: latestBant.totalScore,
          notes: latestBant.notes,
        }
      : null,
    engagement: latestBehavioral
      ? {
          score: latestBehavioral.totalScore,
          level: latestBehavioral.engagementLevel,
          emailOpens: latestBehavioral.emailOpens,
          emailClicks: latestBehavioral.emailClicks,
          siteVisits: latestBehavioral.siteVisits,
          meetingsAttended: latestBehavioral.meetingsAttended,
          callsCompleted: latestBehavioral.callsCompleted,
        }
      : null,
    activities: lead.activities.map((a) => ({
      id: a.id,
      type: a.type,
      description: a.description,
      occurredAt: a.occurredAt,
      by: `${a.createdBy.firstName} ${a.createdBy.lastName}`,
    })),
    opportunities: lead.opportunities.map((o) => ({
      id: o.id,
      stage: o.stage,
      expectedValue: Number(o.expectedValue),
      currency: o.currency,
      unitNumber: o.unit?.unitNumber ?? null,
    })),
    siteVisits: lead.siteVisits.map((v) => ({
      id: v.id,
      status: v.status,
      scheduledAt: v.scheduledAt,
    })),
    tasks: tasks.map((t) => ({
      id: t.id,
      title: t.title,
      description: t.description,
      status: t.status,
      priority: t.priority,
      dueDate: t.dueDate,
      assignedTo: `${t.assignedTo.firstName} ${t.assignedTo.lastName}`,
    })),
  };
}

export type LeadDetail = NonNullable<Awaited<ReturnType<typeof getLeadDetail>>>;
