import { Home, CheckCircle2, CalendarClock, Building2 } from "lucide-react";
import { KpiCard } from "@/components/dashboard/kpi-card";
import { UnitsInventory } from "@/components/sales/units-inventory";
import { getUnitsInventory, getUnitsInventoryKpis, getReservableLeads } from "@/lib/queries/sales";
import { getCurrentUser } from "@/lib/queries/reference";

export default async function ProjectsPage() {
  const [units, kpis, leads, currentUser] = await Promise.all([
    getUnitsInventory(),
    getUnitsInventoryKpis(),
    getReservableLeads(),
    getCurrentUser(),
  ]);

  const developmentCount = new Set(units.map((u) => u.developmentId)).size;

  return (
    <div className="flex flex-col gap-6">
      <div>
        <h1 className="font-heading text-2xl font-semibold">Projects</h1>
        <p className="text-sm text-muted-foreground">
          {developmentCount} development{developmentCount === 1 ? "" : "s"}, {kpis.total.toLocaleString()} units.
        </p>
      </div>

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <KpiCard title="Developments" value={developmentCount.toLocaleString()} icon={Building2} />
        <KpiCard title="Available" value={kpis.available.toLocaleString()} icon={Home} />
        <KpiCard title="Reserved" value={kpis.reserved.toLocaleString()} icon={CalendarClock} />
        <KpiCard title="Sold" value={kpis.sold.toLocaleString()} icon={CheckCircle2} />
      </div>

      <UnitsInventory units={units} leads={leads} currentUserId={currentUser.id} />
    </div>
  );
}
