import { prisma } from "@/lib/prisma";

export type InteractionTimelineItem = {
  id: string;
  type: string;
  subject: string | null;
  notes: string | null;
  occurredAt: Date;
  by: string;
};

// Opportunity has no dedicated activity model — reads straight off the generic Interaction
// table. Customer merges Interaction (calls/meetings/notes) with MarketingMessage (simulated
// email/SMS/WhatsApp sends) so a message logged via the shared action bar shows up here too.
export async function getInteractionTimeline(
  entityType: "OPPORTUNITY" | "CUSTOMER",
  entityId: string
): Promise<InteractionTimelineItem[]> {
  if (entityType === "OPPORTUNITY") {
    const rows = await prisma.interaction.findMany({
      where: { relatedEntityType: "OPPORTUNITY", relatedEntityId: entityId },
      orderBy: { occurredAt: "desc" },
      include: { user: { select: { firstName: true, lastName: true } } },
    });
    return rows.map((i) => ({
      id: i.id,
      type: i.type,
      subject: i.subject,
      notes: i.notes,
      occurredAt: i.occurredAt,
      by: `${i.user.firstName} ${i.user.lastName}`,
    }));
  }

  const [interactions, messages] = await Promise.all([
    prisma.interaction.findMany({
      where: { relatedEntityType: "CUSTOMER", relatedEntityId: entityId },
      orderBy: { occurredAt: "desc" },
      include: { user: { select: { firstName: true, lastName: true } } },
    }),
    prisma.marketingMessage.findMany({
      where: { customerId: entityId },
      orderBy: { createdAt: "desc" },
    }),
  ]);

  const fromInteractions: InteractionTimelineItem[] = interactions.map((i) => ({
    id: i.id,
    type: i.type,
    subject: i.subject,
    notes: i.notes,
    occurredAt: i.occurredAt,
    by: `${i.user.firstName} ${i.user.lastName}`,
  }));
  const fromMessages: InteractionTimelineItem[] = messages.map((m) => ({
    id: m.id,
    type: m.channel,
    subject: m.subject,
    notes: m.body,
    occurredAt: m.sentAt ?? m.createdAt,
    by: "Simulated send",
  }));

  return [...fromInteractions, ...fromMessages].sort((a, b) => b.occurredAt.getTime() - a.occurredAt.getTime());
}
