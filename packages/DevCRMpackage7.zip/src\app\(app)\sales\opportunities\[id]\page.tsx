import { notFound } from "next/navigation";
import Link from "next/link";
import { ArrowLeft } from "lucide-react";
import { OpportunityDetailView } from "@/components/sales/opportunity-detail";
import { getOpportunityDetail } from "@/lib/queries/sales";
import { getInteractionTimeline } from "@/lib/queries/interactions";
import { getCurrentUser } from "@/lib/queries/reference";

export default async function OpportunityDetailPage({ params }: { params: { id: string } }) {
  const [opportunity, currentUser] = await Promise.all([getOpportunityDetail(params.id), getCurrentUser()]);
  if (!opportunity) notFound();
  const timeline = await getInteractionTimeline("OPPORTUNITY", params.id);

  return (
    <div className="flex flex-col gap-6">
      <Link href="/sales" className="flex w-fit items-center gap-1 text-sm text-muted-foreground hover:text-foreground">
        <ArrowLeft className="size-4" /> Back to Sales Pipeline
      </Link>
      <OpportunityDetailView opportunity={opportunity} timeline={timeline} currentUser={{ id: currentUser.id, name: currentUser.name }} />
    </div>
  );
}
