import { notFound } from "next/navigation";
import Link from "next/link";
import { ArrowLeft } from "lucide-react";
import { PaymentScheduleView } from "@/components/finance/payment-schedule-view";
import { getPaymentScheduleForSale } from "@/lib/queries/finance";
import { getCurrentUser } from "@/lib/queries/reference";
import { formatCurrency } from "@/lib/utils";

export default async function SalePaymentSchedulePage({ params }: { params: { saleId: string } }) {
  const [detail, currentUser] = await Promise.all([getPaymentScheduleForSale(params.saleId), getCurrentUser()]);
  if (!detail) notFound();

  return (
    <div className="flex flex-col gap-6">
      <Link href="/finance" className="flex w-fit items-center gap-1 text-sm text-muted-foreground hover:text-foreground">
        <ArrowLeft className="size-4" /> Back to Finance
      </Link>

      <div>
        <h1 className="font-heading text-2xl font-semibold">
          Unit {detail.unitNumber} — {detail.customerName}
        </h1>
        <p className="text-sm text-muted-foreground">
          Sale value {formatCurrency(detail.totalAmount, detail.currency)} · Reservation Deposit, SPA Execution, 4
          Construction Milestones, and Handover — Devtraco's standard payment framework.
        </p>
      </div>

      <PaymentScheduleView detail={detail} currentUserId={currentUser.id} />
    </div>
  );
}
