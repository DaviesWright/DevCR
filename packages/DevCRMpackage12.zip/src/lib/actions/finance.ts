"use server";

import { revalidatePath } from "next/cache";
import { prisma } from "@/lib/prisma";
import { logAudit } from "@/lib/audit";
import { recordPayment as recordPaymentCore, attemptBcSync } from "@/lib/finance/schedule";

export async function recordPayment(input: {
  scheduleId: string;
  amount: number;
  method: "CASH" | "BANK_TRANSFER" | "MOBILE_MONEY" | "CARD" | "CHEQUE" | "OTHER";
  reference: string;
  notes: string;
  actorId: string;
}) {
  if (input.amount <= 0) throw new Error("Payment amount must be greater than zero.");

  const schedule = await prisma.paymentSchedule.findUniqueOrThrow({
    where: { id: input.scheduleId },
    select: { paymentPlan: { select: { saleId: true, sale: { select: { customerId: true } } } } },
  });

  const payment = await recordPaymentCore({
    scheduleId: input.scheduleId,
    customerId: schedule.paymentPlan.sale.customerId,
    saleId: schedule.paymentPlan.saleId,
    amount: input.amount,
    method: input.method,
    reference: input.reference || null,
    notes: input.notes || null,
    actorId: input.actorId,
  });

  await logAudit(input.actorId, "RECORD_PAYMENT", "Payment", payment.id, {
    scheduleId: input.scheduleId,
    amount: input.amount,
  });

  revalidatePath("/finance");
  revalidatePath(`/finance/${schedule.paymentPlan.saleId}`);
  revalidatePath("/sales/commissions");
  return payment;
}

export async function retryBcSync(mirrorTransactionId: string, actorId: string) {
  await attemptBcSync(mirrorTransactionId);
  await logAudit(actorId, "RETRY_SYNC", "BcMirrorTransaction", mirrorTransactionId, {});
  revalidatePath("/finance/reconciliation");
}

export async function retryAllFailedBcSyncs(actorId: string) {
  const failed = await prisma.bcMirrorTransaction.findMany({
    where: { status: { in: ["PENDING", "FAILED"] } },
    select: { id: true },
  });
  for (const row of failed) {
    await attemptBcSync(row.id);
  }
  await logAudit(actorId, "RETRY_ALL_SYNCS", "BcMirrorTransaction", "bulk", { count: failed.length });
  revalidatePath("/finance/reconciliation");
  return { retried: failed.length };
}

// Lazy sweep, same pattern as releaseExpiredReservations (src/lib/actions/sales.ts) — no
// background scheduler exists in this app, so overdue status is persisted on demand rather than
// on a timer. Also freezes/holds any T2/T3 commission tranche gated on that sale's account
// status (recomputeInstalmentGatedTranche in src/lib/actions/commissions.ts already reads
// PaymentSchedule.status === "OVERDUE" for its Client Account Status gate).
export async function refreshOverdueSchedules(actorId: string) {
  const due = await prisma.paymentSchedule.findMany({
    where: { status: { in: ["PENDING", "PARTIAL"] }, dueDate: { lt: new Date() } },
    select: { id: true },
  });
  for (const row of due) {
    await prisma.paymentSchedule.update({ where: { id: row.id }, data: { status: "OVERDUE" } });
  }
  await logAudit(actorId, "REFRESH_OVERDUE", "PaymentSchedule", "bulk", { count: due.length });
  revalidatePath("/finance");
  return { flaggedCount: due.length };
}
